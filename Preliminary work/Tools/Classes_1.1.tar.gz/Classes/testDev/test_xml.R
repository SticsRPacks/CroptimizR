#
# http://www.w3schools.com/xpath/xpath_syntax.asp

# fichier ini stics
# getValues(d,"//initialisations/plante[@dominance='1']/densinitial/horizon")
[[1]]
[1] "0.0"

[[2]]
[1] "0.0"

[[3]]
[1] "0.0"

[[4]]
[1] "0.0"

[[5]]
[1] "0.0"

# getAttrs(d,"//initialisations/plante[@dominance='1']/densinitial/horizon")
 nh  nh  nh  nh  nh 
"1" "2" "3" "4" "5" 
