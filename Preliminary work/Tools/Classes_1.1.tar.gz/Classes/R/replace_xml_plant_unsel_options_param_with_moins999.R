replace_xml_plant_unsel_options_param_with_moins999 <- function(xml_file_path_vector,  xml_out_dir = "output") {
  #' @title Replace in xml plant file, unused parameters values with -999
  #' 
  #' @param xml_file_path_vector Vector of xml files path
  #' @param xml_output_dir Directory name for storing transformed xml files
  #'  (same file name as inputs), optional (default: "output")
  #'  
  #' @export
  replace_SticsUnselOptionsParamValues(xml_file_path_vector, xml_out_dir, "-999", "plt")
}