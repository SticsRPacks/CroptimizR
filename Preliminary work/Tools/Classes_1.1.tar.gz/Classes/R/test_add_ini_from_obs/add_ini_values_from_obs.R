library(Classes)
library(dplyr)
replace_ini_values=TRUE

setwd("/home/plecharpent/Work/workspace/Example_Stics_Tests")
usm_dir="USMs"
ini_dir="USMs"
obs_dir="Obs"

# getting var names
var_names=c(sprintf("HR(%d)",1:5),sprintf("AZnit(%d)",1:5),sprintf("AZmm(%d)",1:5))
var_col=make.names(var_names)

# loading usms  file
usm_file=file.path(usm_dir,"usms.xml")
usms=xmldocument(usm_file)
# getting usms names
#usms_names=getAttrsValues(usms,"//usm","nom")
usms_names=getAttrs(usms,"//usm")

# getting usm names with obs list
usms_obs=gsub(".obs","",list.files(obs_dir,"*.obs"))
# intersect
usms_to_treat=intersect(usms_names,usms_obs)

# getting usm list for which obs files contain any of var_names
# files with vars
nb_usms=length(usms_to_treat)
obs_values=matrix(NA,nb_usms,length(var_names))
rownames(obs_values)<-usms_to_treat
colnames(obs_values)<-var_names
any_var_obs=rep(FALSE,nb_usms)
for (i in 1:nb_usms){
  # getting first date
  name=usms_to_treat[i]
  print(name)
  eval(parse(text=paste0('first_day=as.numeric(getValues(usms,"//usm[@nom=\'',name,'\']/datedebut"))')))

  # loading obs file
  obs_file=file.path(obs_dir,paste0(name,".obs"))
  tbl_obs=as.tbl(read.table(obs_file,header = TRUE,stringsAsFactors = FALSE,sep = ";"))
  # getting data for first day of simulation
  first_day_data=filter(tbl_obs,jul==first_day)

  # no data for first day
  if (dim(first_day_data)[[1]]==0) next
  # fixing NA values
  first_day_data[first_day_data < -900]=NA

  # finding var names in obs matrix
  id_var_in_obs_values=unlist(lapply(colnames(tbl_obs), function(x) which(is.element(var_col,x))))
  # no var found
  if (length(id_var_in_obs_values)==0) next
  # col index in usm obs table
  id_in_tbl_obs=unlist(lapply(var_col, function(x) which(is.element(colnames(tbl_obs),x))))
  # replacing values
  # keeping only the first line of first_day_data (may be another one in 2 years simulation)
  obs_values[i,id_var_in_obs_values]=as.matrix(first_day_data[1,id_in_tbl_obs])

  # checking if any non NA value
  if (!all(is.na(obs_values[i,id_var_in_obs_values]))) {
    any_var_obs[i]=TRUE
  }
}

# usm names with var in obs
usms_to_treat=usms_to_treat[any_var_obs]
obs_values=obs_values[any_var_obs,]
# replacing init values if needed & generating new ini file
if (replace_ini_values) {
  usms_ini_to_replace=matrix(FALSE,length(usms_to_treat),3)
  for (i in 1:length(usms_to_treat)){
    name=usms_to_treat[i]

    eval(parse(text=paste0('ini_file=getValues(usms,"//usm[@nom=\'',name,'\']/finit")')))
    ini_file=file.path(ini_dir,ini_file)
    ini=xmldocument(ini_file)
    # getting ini values and merging with obs values if
    # ini==0 and obs!=NA
    init_values=as.numeric(getValues(ini,"//horizon")[11:25])
    rep_index=!is.na(obs_values[i,]) & obs_values[i,] > 0 # & init_values==0
    # if any value to replace
    # replacing all values with merged values
    if (any(rep_index)){
      print(paste(name,": updating ini file"))
      init_values[rep_index]=obs_values[i,rep_index]
      setValues(ini,"//hinit/horizon",as.character(init_values[1:5]))
      setValues(ini,"//NO3init/horizon",as.character(init_values[6:10]))
      setValues(ini,"//NH4init/horizon",as.character(init_values[11:15]))
      file.copy(ini_file,file.path(ini_dir,paste0(name,"_ini_prev.xml")))
      saveXmlDoc(ini,ini_file)
    }
    
  }
}
