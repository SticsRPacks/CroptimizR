get_option_choix<-function(xmlDoc,x_path,form_list,sub=FALSE){
  sub_str="      + "
  if (!sub){sub_str=""}
#niveau option
  niv_opt="2"
  if (!sub){niv_opt="1"}


    path_base=paste0(x_path,"/option")
    par_list_l1<<-getAttrsValues(xmlDoc,path_base,"nomParam")
    liste_option <<-par_list_l1
    param_list_l1<<-getAttrsValues(xmlDoc,path_base,"nom")
    print("liste_option : ")
    print(liste_option)
    #DR
    path_param=paste0(x_path,"/param")
    param_val=getValues(xmlDoc,path_param)
    param_nb=0
    if (!is.null(param_val)){
      param_nb=length(param_val)
      param_names=getAttrsValues(xmlDoc,path_param,"nom")
    } 
    # DR je mets ca dans un tableau
    #taboption<<-rbind(taboption,data.frame(niveau=c(niv_opt),nom_option=c(opt_nomParam),option_active=c(opt_nom_choix)))
    ligne<<-c(form_list,"0","0","0","0",param_nb)
    toto<<-rbind(toto,ligne)
    #DR
    
  # if not any option block 
  if (is.null(par_list_l1)){
#     # adding parameter number
#     path_param=paste0(x_path,"/param")
#     param_val=getValues(xmlDoc,path_param)
#     param_nb=0
#     if (!is.null(param_val)){
#       param_nb=length(param_val)
#       param_names=getAttrsValues(xmlDoc,path_param,"nom")
#     } 
#     # DR je mets ca dans un tableau
#     #taboption<<-rbind(taboption,data.frame(niveau=c(niv_opt),nom_option=c(opt_nomParam),option_active=c(opt_nom_choix)))
#     ligne<<-c(form_list,"0","0","0","0",param_nb)
#     toto<<-rbind(toto,ligne)
    return(0)
    }
  
  # loop over param options
  for (i in  1:length(par_list_l1)){
    print(paste("=== on traite option niveau 1 :",par_list_l1[i]))
    # first level option
    # pour le code option traite
    opt_nomParam=par_list_l1[i]
    path=paste0(path_base,"[@nomParam='",opt_nomParam,"']")
    opt_code_choix=getAttrsValues(xmlDoc,path,"choix")
    opt_nom=getAttrsValues(xmlDoc,path,"nom")
    # opt_code_choix=
    path=paste0(path,"/choix[@code='",opt_code_choix,"']")
    print(paste("========= path",path))
    opt_nom_choix=getAttrsValues(xmlDoc,path,"nom")
    # displaying option infos
    print(paste(sub_str,opt_nom,"(", opt_nomParam,"): ",opt_nom_choix))

    # je recupere le nb de parametres
    #les parametres
    path_param=paste0(path,"/param")
    param_val=getValues(xmlDoc,path_param)
    param_nb=0
    if (!is.null(param_val)){
     param_nb=length(param_val)
     param_names=getAttrsValues(xmlDoc,path_param,"nom")
     } 
    # DR je mets ca dans un tableau
    #taboption<<-rbind(taboption,data.frame(niveau=c(niv_opt),nom_option=c(opt_nomParam),option_active=c(opt_nom_choix)))
    ligne<<-c(form_list,niv_opt,opt_nom,opt_nomParam,opt_nom_choix,param_nb)
    toto<<-rbind(toto,ligne)
    path_level_2=path    

    # mettre la condition dans la fonction appelee !!!!
    sub_opt=getAttrs(xmlDoc,paste0(path,"/option"))
    if (!is.null(sub_opt)){
      print(paste(">>>>>> entering sub option of ",opt_nom_choix))
      print(paste("========= path level 2",path_level_2))
      get_option_choix_level2(xmlDoc,path_level_2,form_list,TRUE)
    }
    
    
  }
}