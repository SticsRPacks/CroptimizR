xtract_soil_infos<-function(soilsFile="sols.xml",usmsFile=character(0),usmsList=c(),outFile=character(0)){
  
  output=list()
  err=FALSE
  message_txt=""
  
  
  # soils file
  soilsDoc=xmldocument(soilsFile)
  soilnames=getAttrs(soilsDoc,"//sol")
  nb_soils=length(soilnames)
  
  # checking soil names
  if (length(unique(soilnames))!=nb_soils){
    message("Soil names are not all uniques !")
    warning("Check sols.xml file.")
  }
  
  # Getting no optional, no spatial params
  param_list=getAttrsValues(soilsDoc,"//sol[1]/param","nom")
  nb_par=length(param_list)
  # ceating data frame
  result=data.frame(soil=soilnames,stringsAsFactors = FALSE)
  
  # Loop over parameters
  for (p in 1:nb_par){
    pname=param_list[p]
    # init values for each param
    eval(parse(text=paste0("result$",pname,"=rep(NA,nb_soils)")))
    for (i in  1:nb_soils) {
      name = soilnames[i]  
      param_query=paste0("//sol[@nom='",name,"']/param[@nom='",pname,"']")
      # setting query exp_txt expression
      exp_txt=paste0("result$",pname,"[i] = as.numeric(getValues(soilsDoc,param_query)[[1]])")
      eval(parse(text=exp_txt))
    }
  }
  
  # Getting optional parameters
  optform_list=getAttrsValues(soilsDoc,"//sol[1]/option","nomParam")
  nb_opt=length(optform_list)
  
  for (o in 1:nb_opt){
    form = optform_list[o]
    for (i in  1:nb_soils) {
      name = soilnames[i] 
      choice_query=paste0("//sol[@nom='",name,"']/option[@nomParam='",form,"']")
      # recup valeur code
      val_choix=as.numeric(getAttrsValues(soilsDoc,choice_query,"choix"))
      exp_txt=paste0("result$",form,"[i] = val_choix")
      eval(parse(text=exp_txt))
      # ajout des valeurs des parametres associes, NaN si choix = 2
      # recup param names
      param_query=paste0("//sol[@nom='",name,"']/option[@nomParam='",form,"']/choix[@code='1']/param")
      name_param=getAttrsValues(soilsDoc,param_query,"nom")
      # if no param ...
      if (is.null(name_param)) {next}
      # recup valeurs
      val_param=getValues(soilsDoc,param_query)
      # affectation a result
      for (v in 1:length(val_param)){
        val=NaN
        if (val_choix==1) val=val_param[v]
        exp_txt=paste0("result$",name_param[v],"[i] = val")
        eval(parse(text=exp_txt))
      }
    }
  }
  
  # Getting soil layers parameters
  param_tab_list=getAttrsValues(soilsDoc,"//sol[1]/tableau_entete/colonne","nom")
  nb_tab_par=length(param_tab_list)
  layers_list=unique(getAttrsValues(soilsDoc,"//sol/tableau","nom"))
  nb_layers=length(layers_list)
  
  for (l in 1:nb_layers)
  {
    layer=layers_list[l]
    layer_tag=paste0("_",as.character(l))
    for (t in 1:nb_tab_par){
      parname=param_tab_list[t]
      parname_layer=paste0(parname,layer_tag)
      eval(parse(text=paste0("result$",parname_layer,"=rep(NA,nb_soils)")))
      for (i in  1:nb_soils){
        param_query=paste0("//sol[@nom='",soilnames[i],"']/tableau[@nom='",layer,"']/colonne[@nom='",parname,"']")
        eval(parse(text=paste0("result$",parname_layer,"[i] = getValues(soilsDoc,param_query)")))
      }
    }
  }
  
  # adding soil result to output 
  output$soils_param=result
  
  # usms file given
  if (length(usmsFile)){
    # filtering from usms list: full usms file, restricted to an usms names list
    # loading usms file
    usmsDoc=xmldocument(usmsFile)
    usm=getAttrs(usmsDoc,"//usm")

    # usms' soils names
    usmsSoilsList=unlist(getValues(usmsDoc,"//usm/nomsol"))
    
    # checking if usms soil names exist in soils_param
    if(!all(is.element(usmsSoilsList,result$soil))) {
      message_txt="Check usms soil names, not all found in sols.xml file !"
      err=TRUE
      }
    
    # filtering usm names if needed
    if (!is.null(usmsList)){
      usms_idx=is.element(usm,usmsList)
      usm=usm[usms_idx]
      usmsSoilsList=usmsSoilsList[usms_idx]
    }
    
    nb_usms=length(usm)
    
    # if usms: results$usms_soils= table usm name & soil name
    output$usm_soil=data.frame(usm=usm,soil=usmsSoilsList,stringsAsFactors = FALSE)
  }
  

  # testing outputs
  if(err) {
    message(message_txt)
    stop(paste("Failed soil data extraction for usms, see warnings for details !"))
  }
  
  # Optionally : writing soil parameters table to a csv formatted file
  # with only soils params 
  # or with usms / soil params
  if (length(outFile)){
    if (length(usmsFile)){
      # combining usms & soils if usms provided
      param_table=NULL
      # getting soil index
      for (u in 1:nb_usms){
        soils_idx=is.element(output$soils_param$soil,output$usm_soil$soil[u])
        usm_param_line=cbind(output$usm_soil$usm[u],output$soils_param[soils_idx,])
        param_table=rbind(param_table,usm_param_line)
      }
      names(param_table)[1]<-"usm"
    } else {
      param_table=output$soils_param
      
    }
    write.table(param_table,sep = ";", file = outFile, row.names = FALSE,col.names = TRUE,quote = FALSE)
  }
  
  # output returning
  return(output)
}
