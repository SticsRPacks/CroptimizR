xtract_plant_param<-function(plant_file){
  
# getting dir path
dir_path=dirname(plant_file)
plant_fname=basename(plant_file)

# using class xmlDocument
# loading file
plantDoc=xmldocument(file.path(dir_path,plant_fname))
noms_varietes=getAttrs(plantDoc,"//variete")
nb_varietes=length(noms_varietes)

result=list()
# generaux
# sauf 'correspondance code BBCH', ni "stoprac", ni "codeplante"
xpath="//formalisme[@nom!='cultivar parameters' and @nom!='correspondance code BBCH']/param[@nom!='stoprac' and @nom!='codeplante']"
result$general=getValues(plantDoc,xpath)
names(result$general)<-getAttrsValues(plantDoc,xpath,"nom")
result$general=as.data.frame(result$general,stringsAsFactors=FALSE)
dimnames(result$general)[[2]]<-c("value")

# pour correspondance BBCH (less attributes than others)
xpath="//formalisme[@nom!='cultivar parameters' and @nom='correspondance code BBCH']/param"
g=getValues(plantDoc,xpath)
names(g)=getAttrsValues(plantDoc,xpath,"nom")
g=as.data.frame(g,stringsAsFactors=FALSE)
dimnames(g)[[2]]<-c("value")
result$general=rbind(result$general,g)
  
# pour codeplante et stoprac (less attributes than others)
xpath="//formalisme[@nom!='cultivar parameters']/param[@nom='stoprac' or @nom='codeplante']"
g=getValues(plantDoc,xpath)
names(g)=getAttrsValues(plantDoc,xpath,"nom")
g=as.data.frame(g,stringsAsFactors=FALSE)
dimnames(g)[[2]]<-c("value")
result$general=rbind(result$general,g)

# cultivars param values
v1=getValues(plantDoc,"//variete/param")
dim(v1)=c(length(v1)/nb_varietes,nb_varietes)
dimnames(v1)[[1]]=getAttrsValues(plantDoc,"//variete[1]/param","nom")
v2=getValues(plantDoc,"//variete/optionv/param")
dim(v2)=c(length(v2)/nb_varietes,nb_varietes)
dimnames(v2)[[1]]=getAttrsValues(plantDoc,"//variete[1]/optionv/param","nom")

result$cultivar=as.data.frame(rbind(v1,v2))
dimnames(result$cultivar)[[2]]=getAttrsValues(plantDoc,"//variete","nom")


# options param values
v=getValues(plantDoc,"//choix/param")
n=getAttrsValues(plantDoc,"//choix/param","nom")
names(v)=n
result$options=as.data.frame(v,stringsAsFactors=FALSE)
dimnames(result$options)[[2]]=c("value")


return(result)
}