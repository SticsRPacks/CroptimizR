F_gen_xml_tree<-function(csv_file_name,root_name="root"){
  library(stringr)
  
  # Checking that lines separators numbers
  lines_vec=readLines(file(csv_file_name))
  if (length(unique(unlist(lapply(lines_vec,function(x) str_count(x,';')))))>1){
    stop("Check delimiter numbers per line in csv file")
  }
  
  # Checking that " doesn't appear in file
  if (sum(unique(unlist(lapply(lines_vec,function(x) str_count(x,'"')))))){
    stop('Character " exists in file, replace it or suppress it !')
  }
  
  
  # loading file as a data frame
  cdata=read.csv(csv_file_name,sep=";",stringsAsFactors = FALSE)
  
  # filtering all NA cols
  cdata=cdata[!unlist(lapply(cdata, function(x) all(is.na(x))))]
  
  # filtering empty lines
  notmpty=rep(TRUE,dim(cdata)[[1]])
  for (i in 1:dim(cdata)[[1]]){
    notmpty[i]=!(all(is.na(cdata[i,])) || all(cdata[i,]==""))
    
  }
  
  # lines selection
  if (any(notmpty) && !all(notmpty)){
    cdata=cdata[notmpty,]
  }
  if (all(!notmpty)){
    stop("All lines are empty")
  }
  
  # getting nodes levels names
  data_names=names(cdata)
  node_names=data_names[grep('n[0-9]+',data_names)]
  # nodes columns, attributes columns numbers
  nodes_nb=length(node_names)
  attr_nb=dim(cdata)[[2]]-length(node_names)
  # lines number: i.e. xml nodes number
  lines_nb=dim(cdata)[[1]]
  
  # xmltree generation
  tt = xmlHashTree()
  xml_tree=addNode(xmlNode(root_name),character(),tt)
  # starting node level
  current_node=1
  current_node_name=node_names[1]
  
  # initializations
  l=1
  parent_node=xml_tree
  par_node_uid=1
  node_uid=2
  # for storing parent nodes uid
  cdata_parent_uid<-list()
  length(cdata_parent_uid)<-lines_nb*nodes_nb
  dim(cdata_parent_uid)<-c(lines_nb,nodes_nb)
  # for storing nodes content
  cdata_nodes<-list()
  length(cdata_nodes)<-(lines_nb+1)*nodes_nb
  cdata_nodes[[1]]=xml_tree
  
  while (l <= lines_nb){
    # creating node
    node_name=cdata[l,current_node]
    xml_node=xmlNode(node_name)
    # adding attributes if any to the node
    if (attr_nb){
      for (a in 1:attr_nb){
        attr_name=data_names[nodes_nb+a]
        attr_value=cdata[l,nodes_nb+a]
        if (is.na(attr_value)) attr_value=""
        cmd=paste0("xml_node=addAttributes(xml_node,",attr_name," = \"",as.character(attr_value),"\"",")")
        eval(parse(text=cmd))
      }
    }
    
    # adding node to his parent node
    xml_node=addNode(xml_node,parent_node,tt)
    
    # storing nodes
    cdata_nodes[[node_uid]]=xml_node
    cdata_parent_uid[[l,current_node]]=par_node_uid
    
    # function return
    if (l==lines_nb){
      return(xml_tree)
    }
    
    # next node level treatment
    if (!(cdata[l+1,current_node]=="")){
      # si un noeud frere existe (ligne suivante non vide)
      # a priori rien a faire
      par_node_uid=cdata_parent_uid[[l,current_node]]
      l=l+1
    } else if ((current_node+1<=nodes_nb) && !(cdata[l+1,current_node+1]=="")) {
      # si un noeud enfant existe (ligne suivante et colonne suivante non vide)
      parent_node=xml_node
      current_node=current_node+1
      l=l+1
      par_node_uid=node_uid
    } else {
      l=l+1
      # on depile tant que le nom du noeud est vide !
      while (current_node > 1 && cdata[l,current_node]=="") {
        current_node=current_node-1
      }
      current_node_name=node_names[current_node]
      cmdnames=paste0("nameslist=cdata$",current_node_name,"[1:(l-1)]")
      eval(parse(text=cmdnames))
      idx_prev_brother=which(nameslist==cdata[l,current_node])
      idx_prev_brother=idx_prev_brother[length(idx_prev_brother)]
      
      uid_parent=cdata_parent_uid[[idx_prev_brother,current_node]]
      parent_node=cdata_nodes[[uid_parent]]
        
      cdata_parent_uid[[l,current_node]]=uid_parent
      ######################################
      par_node_uid=uid_parent
      ###########################
    
    }
    node_uid=node_uid+1
  }
}
    