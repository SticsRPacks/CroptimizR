
merge_typo_plant<-function(typo_path,usms_file="usms.xml",out_file="new_typo.csv")
{
  # Getting dir path
  dir_path=dirname(typo_path)
  
  # Loading csv typo file
  tt<-try(Typo<-read.table(typo_path,header=T,sep=";",stringsAsFactors=FALSE),silent=TRUE)
  if (is(tt,"try-error")) {
    print(paste0("   Error reading input file: ",typo_path));
    if (!file.exists(typo_path)){
      print(paste0("   File doesn't exist: ",typo_path));
    }
    return
  }
  
  # Extracting plant data
  plant_data=xtract_plant_infos(usms_file)
  
  # Merging typo and plant meta data
  # merged_typo=merge(tt,plant_data,by.x=c("usm"),by.y=c("usm"),all=TRUE,sort=FALSE)
  merged_typo=merge(tt,plant_data,all=TRUE,sort=FALSE)

  # Sorting columns according to original typo first
  # and then plant data columns
  merged_typo=merged_typo[,c(names(tt),setdiff(names(plant_data),names(tt)))]
  
  # Applying unlist for transforming to matrix before writing
  out=apply(merged_typo,2,unlist)
  
  # Writing to a new csv file
  write.table(out,file=file.path(dir_path,"new_typo.csv"),sep=";",row.names=F,quote=F,na="NA")
  
  return(merged_typo)
  
  }