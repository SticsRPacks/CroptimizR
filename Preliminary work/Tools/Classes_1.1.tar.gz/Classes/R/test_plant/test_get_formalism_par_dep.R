plantDoc=xmldocument('wheat_plt.xml')

# recup formalismes hors cultivars
xpath="//formalisme"
form_names=getAttrsValues(plantDoc,xpath,"nom")
form_nb=length(form_names)

form_par=list()
form_par$general=list()
form_par$options=list()
#pargen=c()
#paropt=c()

for (f in 1:form_nb){
  form_name=gsub(" ","_",form_names[f])
  # test extraction parametres generaux pour chaque formalisme
  # xpath="//param[parent::formalisme[@nom='plant name and group']]"
  xpath=paste0("//param[parent::formalisme[@nom='",form_names[f],"']]")
  pargen=getAttrsValues(plantDoc,xpath,"nom")
  
  form_par[["general"]][[form_name]]=pargen
  
  # test extraction parametres options pour chaque formalisme
  xpath=paste0("//choix/param[ancestor::formalisme[@nom='",form_names[f],"']]")
  paropt=getAttrsValues(plantDoc,xpath,"nom") # NULL
  
  form_par[["options"]][[form_name]]=paropt
  
}

# separation optionv ...
xpath=paste0("//choix/param[ancestor::formalisme[@nom='",form_names[f],"']]")



# test extraction parametres  pour formalisme cultivar
xpath="//param[parent::formalisme[@nom='cultivar parameters']]"
getAttrsValues(plantDoc,xpath,"nom")