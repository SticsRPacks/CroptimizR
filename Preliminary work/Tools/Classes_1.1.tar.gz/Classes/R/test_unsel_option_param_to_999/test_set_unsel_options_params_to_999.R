# plant files 
xml_plant_path <- "wheat_plt_ori.xml"
xml_output_path <- "wheat_plt_ori_999.xml"

replace_PlantUnselOptionsParamValues(xml_plant_path,xml_output_path,"-999")


# tec file
# extract loop over general options !
# TODO: common with plant xml files tratment !
xml_tec_path <- "Ble_tec_ori.xml"
xml_output_path <- "Ble_tec_ori_999.xml"
tecDoc = xmldocument(xml_tec_path)
form_attr_mat=getAttrs(tecDoc,"//formalisme/option")
# loop over formalisms
for (p in form_attr_mat[,"nomParam"]) {
  choix = getAttrsValues(tecDoc,paste0('//option[@nomParam="',p,'"]'),"choix")
  xpath=paste0('//option[@nomParam="',p,'"]/choix[@code!="',choix,'"]//param')
  setValues(tecDoc,xpath,"-999")
}

saveXmlDoc(tecDoc,xml_output_path)

# idem station files
# TODO: common with plant xml files treatment !
xml_sta_path <- "climblej_sta_ori.xml"
xml_output_path <- "climblej_sta_ori_999.xml"
staDoc = xmldocument(xml_sta_path)
form_attr_mat=getAttrs(staDoc,"//formalisme/option")
# loop over formalisms
for (p in form_attr_mat[,"nomParam"]) {
  choix = getAttrsValues(staDoc,paste0('//option[@nomParam="',p,'"]'),"choix")
  xpath=paste0('//option[@nomParam="',p,'"]/choix[@code!="',choix,'"]//param')
  setValues(staDoc,xpath,"-999")
}

saveXmlDoc(staDoc,xml_output_path)

# see paramgen and v6
# TODO : see if for the residues list if parameters must be set to -999 
# for other choices than the selected one !!!!!







