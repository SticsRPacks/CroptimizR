replace_stics_xml_doc_unused_options_param <- function(xml_doc,param_list,txt_value,is_cultivar_param = FALSE) {
  
  for (p in param_list) {
    choix = getAttrsValues(xml_doc,paste0('//option[@nomParam="',p,'"]'),"choix")
    if ( is_cultivar_param ){
      xpath=paste0('//optionv[@nom="',p,'"]/param[@code!="',choix,'"]')
    } else {
      xpath=paste0('//option[@nomParam="',p,'"]/choix[@code!="',choix,'"]//param')
      
      # for the selected option (@code = choix), detecting if any sub-option, recursive call in that case
      sub_opt_nodes = getNodeS(xml_doc,paste0('//option[@nomParam="',p,'"]/choix[@code="',choix,'"]/option'))
      if (!is.null(sub_opt_nodes)) {
        form_attr_mat=getAttrs(xml_doc,paste0('//option[@nomParam="',p,'"]/choix[@code="',choix,'"]/option'))
        xml_doc = replace_stics_xml_doc_unused_options_param(xml_doc,form_attr_mat[,"nomParam"],txt_value)
      }
    }
    setValues(xml_doc,xpath,txt_value)
  }
  
  return(xml_doc)
  
}