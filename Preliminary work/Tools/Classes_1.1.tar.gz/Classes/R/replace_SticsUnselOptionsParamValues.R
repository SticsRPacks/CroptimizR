replace_SticsUnselOptionsParamValues <- function(xml_file_path_list, xml_out_dir, in_value, file_type) {
  
  # testing xml_out_dir
  if (!dir.exists(xml_out_dir)) {
    dir.create(xml_out_dir)
  }
  
  # file_types & checking file_type
  file_types = c("plt","tec","sta","par","parv6")
  if (!is.element(file_type,file_types)) {
    stop(paste0("Unknown file type : ",file_type))
  }
  
  is_plt=FALSE
  if(file_type == "plt") {
    is_plt = TRUE
  }
  
  # replacement value & testing length
  txt_value = as.character(in_value)
  if ( length(txt_value) > 1 ) {
    stop(paste0("Too many values : ",txt_values))
  }
  
  # output doc list
  doc_list = vector(mode = "list",length(xml_file_path_list))
  
  for (f in xml_file_path_list) {
    # testing file
    if (!file.exists(f)) {
      warning(paste0("File doesn't exist: ",f))
      next
    }
    
    # loading file
    doc_list[[f]] = xmldocument(f)
    
    # general plant parameters
    # getting general formalisms option attributes (not option of option)
    form_attr_mat=getAttrs(doc_list[[f]],"//formalisme/option")
    doc_list[[f]] = replace_stics_xml_doc_unused_options_param(doc_list[[f]],form_attr_mat[,"nomParam"],txt_value)
    
    if (is_plt) {
      # cultivar plant parameters
      cultivar_params = c("codebfroid","codephot","codlainet","codeindetermin")
      doc_list[[f]] = replace_stics_xml_doc_unused_options_param(doc_list[[f]],cultivar_params,txt_value,TRUE)
    }
    
    # saving new file in output dir
    # TODO : change output file name if needed (adding a tag for replacing value ???
    saveXmlDoc(doc_list[[f]],file.path(xml_out_dir,basename(f)))
  }
  
  return(invisible(doc_list))
}

