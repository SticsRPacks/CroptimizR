xtract_options_infos<-function(xml_file){
 
  toto<<-c() 
  # getting dir path
  dir_path=dirname(xml_file)
  xml_fname=basename(xml_file)
  
  # loading file
  xmlDoc=xmldocument(file.path(dir_path,xml_fname))
  
  # getting param name with options
  path_base="//formalisme"
  path_param="//param"  
  # formalism name
  form_list=getAttrsValues(xmlDoc,path_base,"nom")
  #taboption<<-c('niv_opt','opt_nomParam','opt_nom_choix')  
  for (i in  1:length(form_list)){
   print("")
   print(paste0("_____________ ",form_list[i]," _____________"))

   # calling function for extracting option choix
   get_option_choix(xmlDoc,paste0(path_base,"[@nom='",form_list[i],"']"),form_list[i])
   print("")
   #param_list<<-getAttrsValues(xmlDoc,path_param,"nom")
     }
  taboption<<-data.frame()
}