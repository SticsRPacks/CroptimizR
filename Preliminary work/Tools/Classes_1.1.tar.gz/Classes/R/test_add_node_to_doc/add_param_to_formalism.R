library(Classes)

oriDoc=xmldocument('avigextj_sta_ori.xml')

outXmlName1 = "avigextj_sta_out1.xml"
outXmlName2 = "avigextj_sta_out2.xml"




# using function
# node string to add
nodeString = '<param format="real" max="30.0" min="10.0" nom="aclim">20.00000</param>'
F_add_nodes_to_xml('avigextj_sta_ori.xml','//formalisme[@nom = "Weather station"]',
                   nodeString,nodes_selection=NULL,outXmlName1)


# manually
# getting node to add
refDoc = xmldocument('avigextj_sta_with_added_aclim_ref.xml')
nodes = getNodeS(refDoc,path = '//formalisme[@nom = "Weather station"]/param[@nom = "aclim"]')
addNodes(oriDoc,nodes,'//formalisme[@nom = "Weather station"]')
# saving xml file
saveXmlDoc(oriDoc,outXmlName2)


