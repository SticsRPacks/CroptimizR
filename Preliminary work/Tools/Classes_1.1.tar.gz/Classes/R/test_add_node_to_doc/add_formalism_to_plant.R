library(Classes)
# loading new node as xmlDocument
xnode=xmldocument('formalism_to_add_to_plant.xml')
# change values in xnode tmplate
# list of names and values of parameters to modify
# list of attributes and values to modify !
# example for values
# v=getValues(xnode,'//param[@nom="lvmax"]')
# newv=3
# setValues(xnode,'//param[@nom="lvmax"]',newv)
# # list of values
# newvs=getValues(xnode,'//param')
# newvs[3]=0.150
# newvs[5]=-101000
# setValues(xnode,'//param',newvs)


# using F_add_nodes_to_xml with a file
# inside formalisme 'roots'
# adding nodes contained in formalisme of formalism_to_add_to_plant.xml'
F_add_nodes_to_xml('plant2_plt.xml','/fichierplt/formalisme[@nom="roots"]','formalism_to_add_to_plant.xml','//formalisme/*')

# without a nodes selection in xml to add
# added as a new formalisme node
F_add_nodes_to_xml('plant2_plt.xml','/fichierplt','formalism_to_add_to_plant.xml')


# using F_add_nodes_to_xml with an xmlString
# with or without xml header !
x='<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<formalisme nom="New parameters for perennials">
  <param format="real" max="60.0" min="20.0" nom="parazorac">25</param>
  <option choix="1" nom="simulation of 2 roots classes" nomParam="code_diff_root">
    <choix code="1" nom="yes">
      <param format="real" max="4.0" min="0.0" nom="lvmax">2.6</param>
      <param format="real" max="10.0" min="1.0" nom="rapdia">1.91</param>
      <param format="real" max="0.80" min="0.05" nom="RTD">0.147</param>
      <param format="real" max="1.0" min="0.0" nom="propracfmax">0.72</param>
      <param format="real" max="10" min="0" nom="zramif">-100000</param>
    </choix>
    <choix code="2" nom="no"/>
  </option>
</formalisme>'


F_add_nodes_to_xml('plant2_plt.xml','/fichierplt/formalisme[@nom="roots"]',x,'//formalisme/*')

# with an output file name
F_add_nodes_to_xml('plant2_plt.xml','/fichierplt/formalisme[@nom="roots"]',x,'//formalisme/*','out_plant_plt.xml')



# without a nodes selection in xml to add
# contains formalisme node
# added as a new formalisme node
F_add_nodes_to_xml('plant2_plt.xml','/fichierplt',x,,'out_plant_plt.xml')

