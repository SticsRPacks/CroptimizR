library(Classes)

plant_dir="./plant"

out_plant_dir="./plant_out"

files_list=list.files(plant_dir)

nb=length(files_list)


for (n in 1:nb){
  in_path=file.path(plant_dir,files_list[n])
  out_path=file.path(out_plant_dir,basename(path))
  # Les blocs xml a ajouter viennent du fichier param_newform.xml
  # autant d'appel de la fonction que d'ajouts
  # chaines de selection des noeuds à ajouter : 
  #    '//formalisme[@nom="New parameters for perennials"]/param[@nom="parazorac"]'
  #    '//formalisme[@nom="New parameters for perennials"]/option[@nom="simulation of 2 roots classes"]'
  F_add_nodes_to_xml(in_path,'/fichierplt/formalisme[@nom="roots"]','param_newform.xml','//formalisme[@nom="New parameters for perennials"]/param[@nom="parazorac"]',out_path)
  F_add_nodes_to_xml(out_path,'/fichierplt/formalisme[@nom="roots"]','param_newform.xml','//formalisme[@nom="New parameters for perennials"]/option[@nom="simulation of 2 roots classes"]',out_path)
}

