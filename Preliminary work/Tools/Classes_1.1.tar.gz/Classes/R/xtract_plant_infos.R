xtract_plant_infos<-function(usms_file="usms.xml"){
  
# getting dir path
dir_path=dirname(usms_file)
usms_fname=basename(usms_file)

# using class xmlDocument
# loading files
# usms file
usmsDoc=xmldocument(file.path(dir_path,usms_fname))
usm=getAttrs(usmsDoc,"//usm")
nb_usms=length(usm)

checkTec1=rep(c(''),nb_usms)
checkTec2=rep(c(''),nb_usms)

# usms names & plantfiles
result=data.frame(usm=usm[,1],stringsAsFactors = FALSE)
result$plantfile1=unlist(getValues(usmsDoc,"//usm/plante[@dominance='1']/fplt"))
result$plantfile2=unlist(getValues(usmsDoc,"//usm/plante[@dominance='2']/fplt"))

# usms tec file names
tecList1=unlist(getValues(usmsDoc,"//usm/plante[@dominance='1']/ftec"))
tecList2=unlist(getValues(usmsDoc,"//usm/plante[@dominance='2']/ftec"))
tec=data.frame(tec1=tecList1,tec2=tecList2,stringsAsFactors = FALSE)

# preallocating
# usm plant code fields
result$plantcode1=rep("null",nb_usms)
result$plantcode2=rep("null",nb_usms)
# usm cultivar code fields
result$cultivar1=rep("null",nb_usms)
result$cultivar2=rep("null",nb_usms)

err=FALSE
j=1
k=1

for (i in  1:nb_usms){
  # loading plant file
  pltDoc1=xmldocument(file.path(dir_path,result$plantfile1[i]))
  
  # getting plant code
  result$plantcode1[i]=getValues(pltDoc1,"//formalisme[@nom='plant name and group']/param[@nom='codeplante']")
  
  print(pltDoc1@name)
  
  # Getting cultivars list
  cultivars1=getAttrs(pltDoc1,"//formalisme[@nom='cultivar parameters']/tv/variete")
  nb_cultivars1=length(cultivars1)
  
  # loading tec file
  ftec=tec$tec1[i]
  if (ftec!="null") {
  tecDoc=xmldocument(file.path(dir_path,ftec))
  cultcode=as.numeric(unlist(getValues(tecDoc,"//formalisme[@nom='sowing']/param[@nom='variete']")))
  result$cultivar1[i]=cultivars1[cultcode]
 
   
  
  if (cultcode>nb_cultivars1){
    err=TRUE
    warning(paste("USM ",usm[i],", plant 1: wrong cultivar code in ",ftec," (",cultcode,") over number of cultivars in plant file (",result$plantfile1[i],")"))
    # checking consistency
    checkTec1[j]=paste0("USM ",result$usm[i],", Tec file ",ftec, " NB cultivars in ",result$plantfile1[i]," ",nb_cultivars1," cultivar code ",cultcode)
    j=j+1
    }
  }
  # loading tec file
  ftec=tec$tec2[i]
  if (ftec!="null" && result$plantfile2[i]!="null") {
    tecDoc=xmldocument(file.path(dir_path,ftec))
    pltDoc2=xmldocument(file.path(dir_path,result$plantfile2[i]))
    
    # getting plant name
    result$plantcode2[i]=getValues(pltDoc2,"//formalisme[@nom='plant name and group']/param[@nom='codeplante']")
    
    cultivars2=getAttrs(pltDoc2,"//formalisme[@nom='cultivar parameters']/tv/variete")
    nb_cultivars2=length(cultivars2)
    
    cultcode=as.numeric(unlist(getValues(tecDoc,"//formalisme[@nom='sowing']/param[@nom='variete']")))
    result$cultivar2[i]=cultivars2[cultcode]
    
    
    
    if (cultcode>nb_cultivars2){
      err=TRUE
      warning(paste("USM ",usm[i],", plant 2: wrong cultivar code",ftec," (",cultcode,") over number of cultivars in plant file (",result$plantfile2[i],")"))
      # checking consistency
      checkTec2[k]=paste0("USM ",result$usm[i],", Tec file ",ftec, " NB cultivars in ",result$plantfile2[i]," ",nb_cultivars2," cultivar code ",cultcode)
      k=k+1
      }
  }

}

# saving tec checks
write.table(checkTec1[1:j],file.path(dir_path,"check_tec1.log"))
write.table(checkTec2[1:k],file.path(dir_path,"check_tec2.log"))

# testing outputs
if(err) stop(paste("Failed variety data extraction for usms, see warnings dor details !"))


return(result)
}