F_add_nodes_to_xml<-function(inXmlFile,parent_path_string=NULL,xmlFileOrStringToAdd,nodes_selection=NULL,outXmlFile=character(0)){
  # inXmlFile: input xml file path to modify by adding nodes
  # parent_path_string : xpath of the parent node of the nodes to add
  # xmlFileOrStringToAdd: file path or xml string which contains nodes to add 
  # nodes_selection: xpath of the nodes to add within xmlFileOrStringToAdd
  # outXmlFile: output xml file path, if not given generated from input file path
  
  # testing if xmlFile exists
  # loading it as xmlDocument
  xdoc=xmldocument(inXmlFile)
  
  # testing if parent path exists
  # getting parent node
  #print(nodes_selection)
  
  
  # testing if xmlFileOrStringToAdd is a file or an xmlString
  # loading as xmlDocument / parsing xmlParseString
  # Getting node set to add
  if (isXMLString(xmlFileOrStringToAdd)){
    xaddnode=xmlParseString(xmlFileOrStringToAdd)
    #print(xaddnode)
    if (is.null(nodes_selection)){
      # nodes_selection=paste0('/',xmlName(xmlRoot(xaddnode))) 
      nodes_selection='.' 
      #print(nodes_selection)
    }
    
    # getting node set
    ns_node_to_add=getNodeSet(xaddnode,nodes_selection)
    
    # testing if node set not empty (already done in xmldocument)
    if (!length(ns_node_to_add)) {
      warning("Node set is empty, check xml input path !")
      ns_node_to_add=NULL
    }
  }else{
    xto_add_doc=xmldocument(xmlFileOrStringToAdd)
    ns_node_to_add=getNodeS(xto_add_doc,nodes_selection)
  }
  
  if(is.null(ns_node_to_add)) return()
  
  
  # adding nodeset to xmlFile doc
  if (is.null(parent_path_string)){
   addNodes(xdoc,ns_node_to_add,parent_path_string)
  }else{
    addNodes(xdoc,ns_node_to_add,parent_path_string)
  }
  
  # setting output file path
  # if not given in outXmlFile
  if (length(outXmlFile)==0){
    inpath=dirname(inXmlFile)
    outXmlFile=file.path(inpath,paste0("modified_",basename(inXmlFile)))
  }
  
  # saving xml file
  saveXmlDoc(xdoc,outXmlFile)
  
  
}