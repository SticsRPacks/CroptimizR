# test script for getting attributes matrix
library(Classes)

# case 0 : not any attribute for nodes
testDoc=xmldocument('wheat_plt_ori.xml')
removeAttrs(testDoc,"//formalisme","nom")
attr_mat=getAttrs(testDoc,"//formalisme")

# case 1 : same number of attributes for each node
# 1 attribute
testDoc=xmldocument('wheat_plt_ori.xml')
attr_mat=getAttrs(testDoc,"//formalisme")

# > 1 attributes
attr_mat=getAttrs(testDoc,"//formalisme/option")

# case 2 : 1 missing attribute for some nodes
# 1 attribute

# > 1 attributes


# case 3 : 