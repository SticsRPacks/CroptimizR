modify_soil_infos<-function(soilsData="sols.xml",param_name,param_value,soil_name=character(0),layer_id=NULL,outFile=character(0)){
  
  if (class(soilsData)=="xmlDocument"){
    # Case: soil xmlDocument
    soilsDoc=soilsData
  } else {
    # Case: soils file
    soilsDoc=xmldocument(soilsData)
  }
  
  # Getting param_name data
  param_data=getSoilParamData(soilsDoc,param_name,soil_name,layer_id)
  
  # switch on param_data$type value 
  if (param_data$type=="soil_form"){
    setAttrValues(soilsDoc,param_data$path_str,"choix",param_value)
  } else {
    setValues(soilsDoc,param_data$path_str,param_value)
  }
  
  # Saving changes to a new xml file if outFile provided
  if(length(outFile)){
    # checking file extension
    strs=unlist(strsplit(outFile,"\\."))
    if (length(strs)==1){outFile=paste0(outFile,".xml")}
    saveXmlDoc(soilsDoc,outFile)
  }
  
  # Returning modified xmldocument
  return(soilsDoc)
}

getSoilParamData <- function(soilsDoc,param_name,soil_name=character(0),layer_id=NULL){
  
  soil_sel_str=""
  soil_layer_sel_str=""
  
  # String for soil name selection
  if (length(soil_name)){
    soil_sel_str=paste0("[@nom='",soil_name,"']")
  }
  
  # String for soil layer selection
  if (!is.null(layer_id)){
    soil_layer_sel_str=paste0("[@nom='layer ",layer_id,"']")
  }
  # init returned list
  param_data=list()
  
  
  # Getting parameters names lists 
  # 1: case optionnal formalisms names
  soil_form=unique(getAttrsValues(soilsDoc,"//sol/option",c("nomParam")))
  
  # 2: Case sol/param parameters names
  soil_params=unique(getAttrsValues(soilsDoc,"//sol/param",c("nom")))
  
  # 3: Case sol/option/choix parameters names
  soil_options_params=unique(getAttrsValues(soilsDoc,"//sol/option/choix/param",c("nom")))
  
  # 4: Case sol/tableau/colonne parameters names
  soil_tableau_params=unique(getAttrsValues(soilsDoc,"//sol/tableau_entete/colonne",c("nom")))
  
  #
  # param_name is a form param
  if (is.element(param_name,soil_form)){
    param_data$path_str=paste0("//sol",soil_sel_str,"/option[@nomParam='",param_name,"']")
    param_data$type="soil_form"
  }
  # param_name is a soil param
  if (is.element(param_name,soil_params)){
    is_par=is.element(param_name,soil_params)
    param_data$path_str=paste0("//sol",soil_sel_str,"/param[@nom='",param_name,"']")
    param_data$type="soil_params"
  }
  # param_name is an option param
  if (is.element(param_name,soil_options_params)){
    param_data$path_str=paste0("//sol",soil_sel_str,"/option/choix/param[@nom='",param_name,"']")
    param_data$type="soil_options_params"
  }
  # param_name is a layer param
  if (is.element(param_name,soil_tableau_params)){
    param_data$path_str=paste0("//sol",soil_sel_str,"/tableau",soil_layer_sel_str,"/colonne[@nom='",param_name,"']")
    param_data$type="soil_tableau_param"
  }
  
  return(param_data)
}


