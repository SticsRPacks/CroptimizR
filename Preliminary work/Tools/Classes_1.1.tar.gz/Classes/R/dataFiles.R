loadFile <- function(filepath, h = T, d = ".", s = ";") {
    
    data_f <- try(Obs <- read.table(filepath, header = h, dec = d, sep = s, stringsAsFactors = FALSE), silent = TRUE)
    
    if (is(data_f, "try-error")) {
        print(paste0("   Reading error for file:  ", filepath))
        if (!file.exists(filepath)) {
            print(paste0("   File doesn't exist: ", filepath))
        }
        data_f <- NA
    }
    # checking numerical content
    if (!checkDataContent(data_f)) {
        print(paste0("   Content error (non-numeric columns), check file: ", filepath))
        data_f <- NA
    }
    
    return(data_f)
    
}




checkDataContent <- function(data_f) {
    # return
    isOk = FALSE
    # data frame not empty
    if (all(dim(data_f))) {
        colNames = dimnames(data_f)[[2]]
        isOk = !any(lapply(colNames, function(x) class(eval(parse(text = paste0("data_f$", x))))) == "character")
    }
    return(isOk)
} 
