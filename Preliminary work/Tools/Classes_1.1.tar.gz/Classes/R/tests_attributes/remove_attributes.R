remove_attributes<-function(xml_file,x_path,attr_names) {
d=xmldocument(xml_file)
path_nb=length(x_path)
#print(attr_names)
for (i in  1:path_nb){
  #print(x_path[i])
  
  removeAttrs(d,x_path[i],attr_names)
  
}
saveXmlDoc(d,"test_remove_attr_plt.xml")

}

