x_paths=c("//fichierplt","//option","//param","//optionv")
attr_vector=c(comment="",source="")
xml_file="alfalfa_plt.xml"

add_attributes(xml_file,x_paths,attr_vector)
  
  
