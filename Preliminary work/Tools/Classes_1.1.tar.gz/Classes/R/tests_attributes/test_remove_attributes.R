# x_paths=c("//fichierplt","//option","//param","//optionv")
x_paths=c("//param")
attr_names=c("min","max")
xml_file="alfalfa_plt.xml"
remove_attributes(xml_file,x_paths,attr_names)

  
  

