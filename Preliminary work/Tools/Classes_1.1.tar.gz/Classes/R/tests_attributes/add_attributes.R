add_attributes<-function(xml_file,x_path,attr_vector) {
d=xmlDocument(xml_file)
path_nb=length(x_path)

for (i in  1:path_nb){
  
  addAttrs(d,x_path[i],attr_vector)
  
}
saveXmlDoc(d,"test_add_attr_plt.xml")

}

