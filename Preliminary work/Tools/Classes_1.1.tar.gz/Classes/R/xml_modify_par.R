library(XML)

# example sur un fichier plante
# chargement du fichier
xplt=xmlParse("data/alfalfa_plt.xml")

# remplacement de valeurs
# definition d'une liste de parametres varietaux
par_name=c("stflodrp","adens")
par_val=c("20","-0.7")

node_set_var=getNodeSet(xplt,"//formalisme//param")

for (i in 1:length(par_name)){
  name=par_name[i]

  for (j in 1:length(node_set_var)){
    attr_name=xmlAttrs(node_set_var[[j]])[["nom"]]
    
    if (attr_name==name){
      xmlValue(node_set_var[[j]])<-par_val[i]
    }
  }
}

# remplacement de valeur d'attribut
node_set_var=getNodeSet(xplt,"//formalisme[@nom='plant name and group']/option")
xmlAttrs(node_set_var[[1]])[["choix"]]<-"1"

# ecriture du fichier modifie
saveXML(xplt,"plant/alfalfa_plt_modif.xml")


