# 1 - Getting an example data set to test 'critstatReduction' function use
#
# To be used, the example data set must be copied in the working directory 
# using the get_example_data function, a new folder will be created
# a -- in the current R workspace
get_examples_data(data = "evaluate")

# b -- in a specific folder, when specified as follows
get_examples_data(path = "/path/to/folder",data = "evaluate")


# 2 - Using critstatReduction function for different cases
# Criteria file 
critstat_path="/path/to/folder/evaluate/critstat/critstat_My_evaluation.csv"

# Criteria list to keep
listCrit=c("number-of-usm","number-of-observations","mean-of-measurements","CV-measurements","CV-simulations",
           "RMSE","rRMSE (%)","pRMSEs","pRMSEu","Mean-difference","Relative error (%)")

# Variables list to keep
# Stics variables names
listVar=c("lai(n)","masec(n)","QNplante")
# or real names in critstat table
listVar=c("lai.n.","masec.n.","qnplante")

# Calling function
# giving a variable list
critstatReduction(critstat_path,listVar = listVar)

# giving a criteria list
critstatReduction(critstat_path,listCrit = listCrit)

# giving both criteria and variables lists 
critstatReduction(critstat_path,listCrit = listCrit, listVar = listVar)

# giving both criteria and variable lists and gettig returned value 
critstat_red = critstatReduction(critstat_path,listCrit = listCrit, listVar = listVar)

# using title argument
critstat_path="/path/to/folder/evaluate/critstat"
eval_title = "My_evaluation"
critstat_red = critstatReduction(critstat_path,listCrit = listCrit, listVar = listVar,eval_title = eval_title)
