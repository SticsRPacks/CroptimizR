# 1 - Getting an example data set to test 'removeVarObs' function use
#
# To be used, the example data set must be copied in the working directory 
# using the get_example_data function, a new folder will be created
# a -- in the current R workspace
get_examples_data(data = "evaluate")

# b -- in a specific folder, when specified as follows
get_examples_data(path = "/path/to/folder",data = "evaluate")


# 2 - Using removeVarObs function for different cases
# Variables list to remove
varObs = c("lai(n)","QNplante")

# Removing variables from observaytion files for usms "ble" and "colza"
data_dir="/path/to/folder/evaluate/allinone"
UsmList = c("ble","colza")
removeVarObs(UsmList,data_dir,varObs)

# Same example with all data in separate folders
data_dir="/path/to/folder/evaluate/separate"
removeVarObs(UsmList,data_dir,varObs,flagFolderPerUSM=TRUE)
