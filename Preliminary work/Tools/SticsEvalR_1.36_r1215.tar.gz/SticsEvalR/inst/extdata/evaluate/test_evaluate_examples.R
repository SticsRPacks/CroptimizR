# 1 - For getting criteria names list used in output file
names<-evaluate()

# 2 - Getting an example data set to test 'evaluate' function use
#
# To be used, the example data set must be copied in the working directory 
# using the get_example_data function, a new folder will be created
# a -- in the current R workspace
setwd("/path/to/folder")
get_examples_data(data = "evaluate")

# b -- in a specific folder, when specified as follows
ws_path = "/path/to/folder"
get_examples_data(path = ws_path ,data = "evaluate")


# 3 - Using evaluate function for different cases
#
# Model data are in one folder
# For producing all output files
# if datapath is a relative path to the current workspace
evaluate(datapath = "evaluate/allinone", eval_title = "My evaluation")
# if datapath is an absolute path like "/path/to/folder" or "C:/path/to/folder"
evaluate(datapath = file.path(ws_path,"evaluate","allinone"), eval_title = "My evaluation")

# Model data are in separate folders
evaluate(datapath = "evaluate/separate", flagFolderPerUSM = TRUE, eval_title="My evaluation")
# for an absolute path
evaluate(datapath = file.path(ws_path,"evaluate","separate"), flagFolderPerUSM = TRUE, eval_title = "My evaluation")


# Now we fix the data folder in a variable for the rest of this example
data_dir=file.path(ws_path,"evaluate","allinone")

# For producing all outputs in a specific sub-folder
evaluate(datapath=data_dir,eval_title="My evaluation",outFolder="MyOutputFolder")

# Getting only dynamic plots with statistics (with arguments names)
evaluate(datapath=data_dir,eval_title="My evaluation 1",CritPlot=0,ScatterPlot=0)

# Selecting data to treat
# USMs selection
evaluate(datapath=data_dir,eval_title="My evaluation 2",UsmsList=c("ble","bledur"))

# Variables selection
evaluate(datapath=data_dir,eval_title="My evaluation 3",Var2Consider=c("lai(n)","mafruit"))

# Variables removing
evaluate(datapath=data_dir,eval_title="My evaluation 4",Var2Remove=c("zrac","resmes"))

# Maximum variables values option
evaluate(datapath=data_dir,eval_title="My evaluation 5",VarSelectMaxValue=c("lai(n)","mafruit"))
