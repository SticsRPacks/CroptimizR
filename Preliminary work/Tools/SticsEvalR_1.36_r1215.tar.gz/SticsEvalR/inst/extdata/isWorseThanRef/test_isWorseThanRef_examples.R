# 1 - Getting an example data set to test 'isWorseThanRef' function use
#
# To be used, the example data set must be copied in the working directory 
# using the get_example_data function, a new folder will be created
# a -- in the current R workspace
get_examples_data( data = "isWorseThanRef")

# b -- in a specific folder, when specified as follows
get_examples_data(path = "/path/to/folder", data = "isWorseThanRef")


# 2 - Using isWorseThanRef function for different cases
#
# Now we fix the data folder in a variable for the rest of this example
data_dir="/path/to/folder/isWorseThanRef"

# Testing if any of the RMSE of each variable in the critstat_eval_NEW.csv file is superior to 5% of the RMSE of the corresponding variables in the critstat_eval.csv file.
isWorseThanRef(file.path(data_dir,'critstat_eval.csv'),file.path(data_dir,'critstat_eval_NEW.csv'),critName="RMSE",RelThreshold=5,flagInf=TRUE)

# Testing if any of the efficiency of each variable in the critstat_eval_NEW.csv file is inferior to 5% of the efficiency of the corresponding variables in the critstat_eval.csv file.
isWorseThanRef(file.path(data_dir,'critstat_eval.csv'),file.path(data_dir,'critstat_eval_NEW.csv'),critName="Model-efficiency (EF)",RelThreshold=5,flagInf=FALSE)

# Testing if any of the efficiency of each variable in the critstat_eval_NEW.csv file is inferior to 50% of the efficiency of the corresponding variables in the critstat_eval.csv file.
isWorseThanRef(file.path(data_dir,'critstat_eval.csv'),file.path(data_dir,'critstat_eval_NEW.csv'),critName="Model-efficiency (EF)",RelThreshold=50,flagInf=FALSE)

