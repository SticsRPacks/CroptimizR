getSimData <- function( file_name ){
  # @title Getting data from sti file
  # @return A named list with $usm (usm name) $table (a tibble), $names (Stics variables), $number (count per variable)
  return(getData(file_name,"sti"))
}