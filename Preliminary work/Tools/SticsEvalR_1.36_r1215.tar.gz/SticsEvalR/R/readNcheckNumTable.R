readNcheckNumTable <- function(file_path){
# @title Get a numerical table from csv file
# @description function used to read a numerical table from csv file and 
# @description managing reading or content type errors
# @param file_path a csv file relative or absolute path 
# @return a list with $error (logical value: FALSE if no errors nd TRUE otherwise) and $data (data frame)
#
  
  readErrorStatus <- FALSE
  content=data.frame()
  
  #t<-try(content<-read.table(file_path,header=T, dec=".",sep=";",stringsAsFactors = FALSE),silent=TRUE)
  t<-try(content<-getData(file_path)$table,silent=TRUE)
  
  # Reading error or bad content (not any columns of variables)
  if (is(t,"try-error") || (dim(content)[[2]] < 5)) {
    print(paste0("   Error reading data file : ",basename(file_path)))
    if (!file.exists(file_path)){
      print(paste0("   File doesn't exist: ",file_path))
    } else {
      print(paste0("   Check file format : ",file_path))
    }
    readErrorStatus <- TRUE
  }
  
  # Table content checking
  if (!readErrorStatus){
    # Checking col types: only integer & numeric
    readErrorStatus=!all(unlist(lapply(content,function(x) class(x)=="numeric" | class(x)=="integer")))
  }
  return(list(data=content,error=readErrorStatus))
}