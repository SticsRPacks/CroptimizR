varnamesToCol <- function(var_list=c()) {
  # @title Convert Stics variables names to consistent columns names strings 
  # @param var_list Stics variables names list
  # @return list of valid column names
  #
  #
  return(make.names(var_list))
  
}