critstatReduction <- function(critstatPath,listCrit=c(),listVar=c(),eval_title="",new_suffix="") {
# Giving and writing a reduced critstat table with given criteria and/or variables list 
  if (is.null(listCrit) && is.null(listVar)){
    warning("Variables an criteria lists are empty, aborting !")
    return()
  }
  
  # replacing blanks with "_"
  eval_title = gsub(x=eval_title,pattern = " ",replacement = "_")
  
  # critstat file path
  # critstatPath : directory
  if (dir.exists(critstatPath)){
    file_path=file.path(critstatPath,paste0("critstat",eval_title,".csv"))
    out_path=critstatPath
  } else {
    # critstatPath : file
    file_path=critstatPath
    out_path=dirname(critstatPath)
  }
  
  # checking file
  if ( ! file.exists(file_path)){
    stop(paste0("File doesn't exists: ",file_path))
  }
  
  # reformatting names as in table
  critstat <- try(read.table(file_path,header=T, dec=".",sep=";"),TRUE)
  
  # if reading error, next usm
  if (is(critstat, "try-error")) {
    warning(paste0("Criteria file could not be loaded: ", file_path))
  }
  
  # recalculating var list
  if (is.null(listVar)) {
    listVar = names(critstat)
  } else {
    listVar=tolower(make.names(listVar))
  }
  
  # recalculating criteria list
  if (is.null(listCrit)) {
    listCrit =rownames(critstat)
  }
  
  # lists to keep in reduced table
  listVarPresentes=intersect(colnames(critstat),listVar)
  listCritPresents=intersect(rownames(critstat),listCrit)
  critstatRed<-critstat[listCritPresents,listVarPresentes]
  
  # Writing a new file with reduced critstat table, in the same directory as the original file
  write.table(critstatRed,file.path(out_path,paste0("critstat_red",new_suffix,".csv")),sep=";") 
  
  return(invisible(critstatRed))
  
}