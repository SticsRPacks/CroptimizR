getObsData <- function( file_name ){
  # @title Getting data from obs file
  # @return A named list with $usm (usm name) $table (a tibble), $names (Stics variables), $number (count per variable)
  return(getData(file_name,"obs"))
}