get_examples_data <- function(path = ".",data=NULL) {
  # @title Get package example data
  # @description  Getting a copy of help examples data folders
  # path: relative or absolute path to the destination folder
  # data : name of the folder linked to the target use of the data
  # i.e. : 
  #   "evaluate" for testing functions: evaluate, critStatReduction, removeVarObs 
  #   "isWorseThanRef" for testing isWorseThanRef function
  #
  get_out=FALSE
  data_names=c("evaluate","isWorseThanRef")
  
  if (nargs() == 0) {
    return(data_names)
  }
  
  if (!dir.exists(path)) {
    stop("The directory path doesn't exist !")
  }
  
  if (is.null(data)) {
    get_out=TRUE
    warning("Missing function name, as function input !")
  } else if (!is.element(data,data_names)) {
    get_out=TRUE
    warning("Wrong function name, as funtion input !")
  }
  
  if (get_out) {
    warning("You must specify the exact function name from which example data depend on!")
    stop("Check the available functions names using get_exemples_data() in the command line !")
  }
  
  data_dir=system.file(paste0("extdata/",data), package = "SticsEvalR")
  # absolute destination path
  dest_path=file.path(path,data)
  
  if (!dir.exists(dest_path)) {
    # copying data
    # TODO mettre un try !!!
    r=file.copy(from = data_dir, to = path,recursive = TRUE)
  } else {
    stop(paste0("The directory '",data, "' already exists in ",normalizePath(path), " !\nRemove it or rename it first and launch again the function." ))
  }
  
  return(invisible(normalizePath(dest_path)))
  
}