########################################################################################
#  Comparaison "Simules-Observes" d'une serie de simulations avec STICS                #
########################################################################################
# Elsa Coucheney

# Cet outil va nous permettre des comparer les differences entre observes et simules via differentes sorties graphiques et le calcul de
# criteres statistiques

# Nous allons donc
# 1- Recuperer les variables (a) observees dans nos fichier .obs et (b) simulees dans nos fichiers de sorties de STICS
#    et creer un tableau de synthese Obs - Sim pour l'ensemble des usm
# 2- Calculer des criteres statistiques de comparaison Obs - Sim
#    imprimer un tableau critstatxxx.csv de synthese et des barplots pour les differents criteres statistiques
# 3- Dessiner des graphiques Sim-Obs en mettant en commun toutes les usm et toutes les dates
# 4- Dessiner des graphiques dynamiques (valeurs en fonction du temps) des variables observees et simulees ; par usm

evaluate <-
  function(datapath,
           flagFolderPerUSM = FALSE,
           eval_title = "",
           outFolder = "results",
           usmFile = "usms.xml",
           CritCalc = 1,
           CritPlot = 1,
           ScatterPlot = 1,
           DynPlot = 1,
           DynPlotVarSort = 1,
           UsmsList = c(),
           Var2Remove = c(),
           Var2Consider = c(),
           VarSelectMaxValue = c(),
           flagIgnoreInitObs = FALSE) {
    
    # List of criteria
    crit_names <- getCriteriaData()$names
    
    # Checking number of arguments
    # If not any: returned value is the criteria list
    if (nargs() == 0) {
      return(crit_names)
    }
    
    # Managing options dependencies
    # Criteria file needed for criteria plots and scatterplots
    if (CritPlot == 1 || ScatterPlot == 1) {
      CritCalc = 1
    }
    # DynPlotVarSort option depends on DynPlot (rmse calculation reused in DynPlotVarSort)
    if (DynPlot == 0 & DynPlotVarSort == 1) {
      DynPlot = 1
    }
    
    # Output directory management
    # for rewriting absolute path
    # Windows / unix form
    abs_lin = gregexpr("/", outFolder)[[1]][1] == 1
    abs_win = gregexpr(":", outFolder)[[1]][1] == 2
    if (abs_lin || abs_win) {
      chficsortie = outFolder
    } else {
      chficsortie = file.path(datapath, outFolder)
    }
    if (!file.exists(chficsortie)) {
      if (!dir.create(chficsortie)) {
        stop("Could not create output directory !", call. = FALSE)
      }
    }
    
    suffix_tag = gsub(x=eval_title,pattern = " ",replacement = "_")
    # Managing eval_title content as suffix for files naming
    if (suffix_tag != "" && gregexpr("_", suffix_tag)[[1]][1] != 1) {
      suffix_tag = paste0("_", suffix_tag)
    }
    
    ##############################################################################################################################
    #1- Recuperer les variables observees dans nos fichier .obs et simulees dans nos fichiers de sorties de STICS
    #    et creer un tableau de synthese Obs - Sim pour l'ensemble des usm
    ##############################################################################################################################
    
    # Lecture du fichier usm pour recuperer le nom des fichiers obs et sti dans le vecteur 'BatFich'
    # on recherche et on parse le fichier xml cible; xmlTree est la representation enregistree de la structure du fichier xml
    usm_path = file.path(datapath, usmFile)
    # Error if usm file doesn't exist
    if (!file.exists(usm_path)) {
      stop(paste0("Usm file doesn't exist: ", usm_path))
    }
    xmlTree = try(xmlParse(usm_path), TRUE)
    # Error while file reading
    if (is(xmlTree, "try-error")) {
      stop(paste0("Usm file could not be loaded: ", usm_path))
    }
    
    # on recupere tous les attributs "nom"
    NodeSet = getNodeSet(xmlTree, "//@nom")
    BatFich = as.character(lapply(NodeSet, function(x)
      x[[1]]))
    
    # Verification que les USMs de la liste passee en argument sont bien dans le fichier des USMs
    #
    if (length(UsmsList) > 0) {
      if (length(setdiff(UsmsList, BatFich)) > 0) {
        warning("At least one usm in given UsmList doesn't exist in usms.xml file, skipped !")
      }
      BatFich = intersect(UsmsList, BatFich)
    }
    
    print("USMs names list to evaluate: ")
    print(BatFich)
    count = 1
    countErrObs = 1
    countErrSim = 1
    PbBatchFichObs = vector()
    PbBatchFichSim = vector()
    FinalBatchFich = vector()
    USMFolder = ""
    
    if (length(VarSelectMaxValue) > 0) {
      #VarSelectMaxValue <- gsub("\\(", ".", VarSelectMaxValue)
      #VarSelectMaxValue <- gsub("\\)", ".", VarSelectMaxValue)
      VarSelectMaxValue <- varnamesToCol(tolower(VarSelectMaxValue))
    }
    
    # Nous allons importer les fichiers observes .obs et les fichiers simules .sti
    for (q in  1:length(BatFich)) {
      usm_name = BatFich[q]
      print(paste0(
        "Processing the observations and simulated data for USM ",
        usm_name
      ))
      
      if (flagFolderPerUSM) {
        USMFolder = usm_name
      }
      
      # Getting observations data
      obs_list = readNcheckNumTable(file.path(datapath, USMFolder, paste0(usm_name, ".obs")))
      Obs = as.data.frame(obs_list$data)
      if (obs_list$error) {
        PbBatchFichObs[countErrObs] = usm_name
        countErrObs = countErrObs + 1
      }
      
      # Getting simulations data
      sim_list = readNcheckNumTable(file.path(datapath, USMFolder, paste0("mod_s", usm_name, ".sti")))
      Sim = as.data.frame(sim_list$data)
      if (sim_list$error) {
        PbBatchFichSim[countErrSim] = usm_name
        countErrSim = countErrSim + 1
      }
      
      # Checking if any file errors
      if (obs_list$error | sim_list$error) {
        next
      } else {
        FinalBatchFich[count] = usm_name
      }
      
      # Nous allons creer une colonne avec le nom de l'usm et la greffer a la dataframe'Obs'
      # Creons un vecteur de longueur de la dataframe Obs
      usm <- rep(usm_name, nrow(Obs))
      # Rajoutons ce vecteur a la dataframe Obs
      Obs <- cbind(usm, Obs)
      
      # Traitement de la casse des noms de variables
      names(Obs) <- tolower(names(Obs))
      
      # traitement VarSelectMaxValue
      maxDate <-
        data.frame(
          ian = rep(NA, length(VarSelectMaxValue)),
          mo = rep(NA, length(VarSelectMaxValue)),
          jo = rep(NA, length(VarSelectMaxValue))
        )
      VarSelectMaxValueTmp = intersect(VarSelectMaxValue, names(Obs))
      if (length(VarSelectMaxValueTmp) > 0) {
        for (ivar in  1:length(VarSelectMaxValueTmp)) {
          tmp <- rep(NA, nrow(Obs))
          varName <- paste0(VarSelectMaxValueTmp[ivar], ".maxvalue")
          Obs <- cbind(Obs, tmp)
          names(Obs)[ncol(Obs)] <- varName
          ind <- which.max(Obs[, VarSelectMaxValueTmp[ivar]])
          maxDate[ivar, ] <- Obs[ind, c("ian", "mo", "jo")]
          Obs[ind, varName] <-
            Obs[ind, VarSelectMaxValueTmp[ivar]]
        }
      }
      
      # if flagIgnoreInitObs option activated and presence of observations at initial simulation date
      IndexObsInit = (Obs[, "jul"] == Sim[1, "jul"] &
                        Obs[, "ian"] == Sim[1, "ian"])
      if (flagIgnoreInitObs && any(IndexObsInit)) {
        varInit = getInitVarNames(R_varnames = TRUE,to_lower = TRUE)
        
        # TODO : make a function to replace values, not only NA
        # calculating init varnames position in Obs 
        # col_idx = is.element(colnames(Obs),varInit)
        # if any varname in Obs table, setting values to NA 
        # if(any(col_idx)) {
        #   Obs[IndexObsInit, col_idx] = NA   
        # }
        
        for (ivar in  1:length(varInit)) {
          # replace initial obs value by NA for the list of variables defined above
          if (any(colnames(Obs) == varInit[ivar]))
            Obs[IndexObsInit, varInit[ivar]] = NA   
        }
      }
      
      # Mettons a la suite les differentes dataframes 'Obs' du Batch
      if (count == 1) {
        Obs.tot <- Obs
      } else {
        Obs.tot <- merge(Obs.tot,
                         Obs,
                         all.x = TRUE,
                         all.y = TRUE,
                         sort = FALSE)
      }
      
      # Creons un vecteur de longueur du fichier BatFich pour entrer le nom de l'usm
      usm <- rep(usm_name, nrow(Sim))
      # Rajoutons ce vecteur a la dataframe 'Sim'
      Sim <- cbind(usm, Sim)
      
      # traitement MaxValue
      VarSelectMaxValueTmp = intersect(VarSelectMaxValue, names(Sim))
      if (length(VarSelectMaxValueTmp) > 0) {
        for (ivar in  1:length(VarSelectMaxValueTmp)) {
          tmp <- rep(NA, nrow(Sim))
          varName <- paste0(VarSelectMaxValueTmp[ivar], ".maxvalue")
          Sim <- cbind(Sim, tmp)
          names(Sim)[ncol(Sim)] <- varName
          ind <-
            which((Sim[, "ian"] == maxDate[ivar, "ian"]) &
                    (Sim[, "mo"] == maxDate[ivar, "mo"]) &
                    (Sim[, "jo"] == maxDate[ivar, "jo"]))
          # option comparaison au max -> potentiellement pas a la meme date que les obs.
          indMax <-
            which.max(Sim[, VarSelectMaxValueTmp[ivar]])    
          Sim[ind, varName] <- Sim[indMax, VarSelectMaxValueTmp[ivar]]
        }
      }
      
      # Mettons a la suite les differentes dataframes 'Sim' du Batch
      if (count == 1) {
        Sim.tot <- Sim
      } else {
        if (dim(Sim.tot)[[2]] != dim(Sim)[[2]]) {
          stop("Check model output files, for the moment they must contain the same variables !")
        }
        Sim.tot <- rbind(Sim.tot, Sim)
      }
      count = count + 1
    }
    
    Nbre.USM <- length(FinalBatchFich)
    print("")
    print(paste0("Final number of selected USMs : ", Nbre.USM))
    if (length(PbBatchFichObs) > 0) {
      print(
        "Following USM(s) have been excluded because of reading error(s) for observation data file(s) : "
      )
      print(PbBatchFichObs)
    }
    if (length(PbBatchFichSim) > 0) {
      print(
        "Following USM(s) have been excluded because of reading error(s) for simulated data file(s) : "
      )
      print(PbBatchFichSim)
    }
    if ((length(PbBatchFichObs) > 0) ||
        (length(PbBatchFichSim) > 0)) {
      if (Nbre.USM == 0) {
        stop("All USMs have been excluded, processing is stopped !")
      }
    }
    
    Obs.tot <- replace(Obs.tot, Obs.tot == -999.99, NA)
    # on met tout les noms en minuscule pour eviter les pb lies a des casses differentes
    names(Sim.tot) <- tolower(names(Sim.tot))
    
    if (length(Var2Remove) > 0) {
      #Var2Remove <- tolower(Var2Remove)
      #Var2Remove <- gsub("\\(", ".", Var2Remove)
      #Var2Remove <- gsub("\\)", ".", Var2Remove)
      Var2Remove <- varnamesToCol(tolower(Var2Remove))
      
      areElements <-
        sapply(Var2Remove, function(x)
          is.element(x, names(Obs.tot)))
      if (!all(areElements)) {
        print(
          paste(
            "WARNING: the variable ",
            Var2Remove[!areElements],
            " you asked to remove is not contained in Obs files."
          )
        )
        Var2Remove <- intersect(Var2Remove, names(Obs.tot))
      }
      if (any(areElements)) {
        Obs.tot <-
          as.data.frame(Obs.tot[, -sapply(Var2Remove, function(x)
            which(names(Obs.tot) == x))])
      }
    }
    if (length(Var2Consider) > 0) {
      #Var2Consider <- tolower(Var2Consider)
      #Var2Consider <- gsub("\\(", ".", Var2Consider)
      #Var2Consider <- gsub("\\)", ".", Var2Consider)
      
      Var2Consider <- varnamesToCol(tolower(Var2Consider))
      
      if (length(VarSelectMaxValue) > 0) {
        Var2Consider <- c(Var2Consider, paste0(VarSelectMaxValue, ".maxvalue"))
      }
      areElements <-
        sapply(Var2Consider, function(x)
          is.element(x, names(Obs.tot)))
      if (!all(areElements)) {
        print(
          paste(
            "WARNING: the variable",
            Var2Consider[!areElements],
            "you asked to consider is not contained in Obs files."
          )
        )
        Var2Consider <- intersect(Var2Consider, names(Obs.tot))
        if (length(Var2Consider) == 0) {
          stop("Error: No variables you asked to consider were found in Obs files.")
        }
      }
      Obs.tot <-
        as.data.frame(Obs.tot[, c(1, 2, 3, 4, 5, sapply(Var2Consider, function(x)
          which(names(Obs.tot) == x)))])
    }
    
    
    write.table(
      Obs.tot,
      file.path(chficsortie, paste0("DonneesObservees", suffix_tag, ".csv")),
      sep = ";",
      row.names = F,
      quote = F
    )
    write.table(
      Sim.tot,
      file.path(chficsortie, paste0("DonneesSimulees", suffix_tag, ".csv")),
      sep = ";",
      row.names = F,
      quote = F
    )
    
    # Exportons le tableau synthetisant les variables observees et simulees en parallele
    bynames = c("usm", "ian", "mo", "jo", "jul")
    if (!all(intersect(names(Obs.tot), bynames) == bynames)) {
      stop(
        "Indication: Check the 5 first columns names of observed data, they must correspond exactly to:  usm,ian,mo,jo,jul"
      )
    }
    Tab.tot <-
      merge(
        Sim.tot,
        Obs.tot,
        by.x = bynames ,
        by.y = bynames ,
        all.y = TRUE,
        all.x = TRUE,
        sort = FALSE
      )
    
    
    # Calcul des residus et insertion dans Tab.tot
    nomVarObs <- names(Obs.tot)
    nomVarSim <- names(Sim.tot)
    nomVarResTmp <- intersect(nomVarObs, nomVarSim)
    indDates <-
      sapply(
        bynames,
        FUN = function(x, y)
          which(y == x),
        y = nomVarResTmp
      )
    nomVarRes <- nomVarResTmp[-indDates]
    Res.tot <-
      Tab.tot[paste(nomVarRes, ".y", sep = "")] - Tab.tot[paste(nomVarRes, ".x", sep =
                                                                  "")]
    names(Res.tot) <- paste(nomVarRes, ".res", sep = "")
    Tab.tot <- cbind(Tab.tot, Res.tot)
    
    # Ecriture de Tab.tot dans un fichier csv
    write.table(
      Tab.tot,
      file.path(chficsortie, paste0("Sim_Obs", suffix_tag, ".csv")),
      sep = ";",
      row.names = F,
      quote = F
    )
    
    
    
    ##############################################################################################################################
    #2- Dessiner des graphiques dynamiques (valeurs en fonction du temps) des variables observees (O) et simulees (P) ; par usm	##
    ##############################################################################################################################
    if (DynPlot == 1) {
      # Creation d'un fichier pdf ou seront enregistrees les figures
      pdf(
        file.path(
          chficsortie,
          paste0("Graph_dynamiques", suffix_tag, ".pdf")
        ),
        paper = "a4",
        width = 7,
        height = 10
      )
      par(oma = c(2, 0, 4, 0))
      par(mar = c(8, 6, 4, 4))
      par(mfrow = c(2, 1))
      plot(
        0,
        xaxt = 'n',
        yaxt = 'n',
        bty = 'n',
        pch = '',
        ylab = '',
        xlab = ''
      )
      text(0, paste0("Total number of USMs: ", Nbre.USM), cex = 1.5)
      plot(
        0,
        xaxt = 'n',
        yaxt = 'n',
        bty = 'n',
        pch = '',
        ylab = '',
        xlab = ''
      )
      title(
        main = paste0("Dynamics plots ", eval_title),
        outer = T,
        cex.main = 1.5
      )
      
      par(mfrow = c(3, 2)) # Parametres de la fenetre graphique
      
      # Initialisation de la matrice des RMSE par USM
      rmsePerUsm = as.data.frame(matrix(
        ncol = ncol(Sim.tot) - 4,
        nrow = length(FinalBatchFich)
      ))
      colnames(rmsePerUsm) = c("usms", colnames(Sim.tot[, 6:ncol(Sim.tot)]))
      rownames(rmsePerUsm) = FinalBatchFich
      rmsePerUsm[, 1] <- FinalBatchFich
      VminTot = rep(NA, length(Obs.tot) - 5)
      VmaxTot = rep(NA, length(Obs.tot) - 5)
      names(VminTot) = colnames(Obs.tot[, 6:ncol(Obs.tot)])
      names(VmaxTot) = colnames(Obs.tot[, 6:ncol(Obs.tot)])
      
      # Nous allons traiter une a une les differentes USMs de notre batch a partir des matrices 'Sim.tot' et 'Obs.tot'
      for (q in 1:length(FinalBatchFich)) {
        Sim.tot.q <-
          subset(Sim.tot, as.character(Sim.tot[, 1]) == FinalBatchFich[q])
        # on enleve les variables sans sim pour cette usm
        Sim.tot.q <-
          Sim.tot.q[, colSums(is.na(Sim.tot.q)) < nrow(Sim.tot.q)]
        Obs.tot.q <-
          subset(Obs.tot, as.character(Obs.tot[, 1]) == FinalBatchFich[q])
        # on enleve les variables sans Obs pour cette usm
        Obs.tot.q <-
          Obs.tot.q[, colSums(is.na(Obs.tot.q)) < nrow(Obs.tot.q)]
        
        if (ncol(Sim.tot.q) <= 5 | length(Obs.tot.q) <= 5) {
          print(
            paste0(
              "Problem with ",
              FinalBatchFich[q],
              " : observed variables number = ",
              ncol(Obs.tot.q) - 5,
              " ; simulated variables number = ",
              length(Sim.tot.q) - 5
            )
          )
          next()
        }
        
        plot(
          0,
          xaxt = 'n',
          yaxt = 'n',
          bty = 'n',
          pch = '',
          ylab = '',
          xlab = ''
        )
        text(0, paste0("usm num. ", q, " :", FinalBatchFich[q]), cex = 1.5)
        
        tabMerge <-
          merge(
            Sim.tot.q,
            Obs.tot.q,
            by.x = c("usm", "ian", "mo", "jo", "jul"),
            by.y = c("usm", "ian", "mo", "jo", "jul"),
            all.y = TRUE,
            all.x = FALSE,
            sort = FALSE
          )
        colnames(tabMerge) <-
          c(colnames(Sim.tot.q), paste0(colnames(Obs.tot.q)[6:ncol(Obs.tot.q)], "obs"))
        
        # Nous recuperons pour chaque variable observee, le couple valeur observee vs simulee (i et j sont les indices pour les variables
        # simulee et observee respectivement)
        for (i in 6:length(Sim.tot.q)) {
          for (j in 6:length(Obs.tot.q)) {
            if (names(Sim.tot.q[i]) == names(Obs.tot.q[j]))
              # On pourrait remettre un test quelquepart pour 
              # eviter de tracer les plots dynamiques pour les variables maxValue
                {
              
              #si la variable simulee est aussi une variable observee
              P.mat <-
                na.omit(data.frame(cbind(Sim.tot.q[, 1:5], Sim.tot.q[, i])))
              O.mat <-
                na.omit(data.frame(cbind(Obs.tot.q[, 1:5], Obs.tot.q[, j])))
              
              if (nrow(O.mat) > 0) {
                #uniquement si nous avons des observes
                if (nrow(P.mat) > 0) {
                  #uniquement si la variable est simulee
                  
                  # Axes "temps" du graphique pour simules
                  dates.P <- P.mat[, 2:4]
                  dates.P <-
                    as.matrix(paste(dates.P[, 3], dates.P[, 2], dates.P[, 1], sep = "/"))
                  annees <- as.factor(P.mat[, 2])
                  alevels <- levels(annees)
                  
                  if (length(alevels) == 1) {
                    annee <- paste0("year ", as.numeric(alevels[1]))
                  } else
                    if (length(alevels) == 2) {
                      annee <-
                        paste0("years ",
                               as.numeric(alevels[1]),
                               "-",
                               as.numeric(alevels[2]))
                    }
                  temps.P <- as.Date(dates.P[, 1], format = "%d/%m/%Y")
                  nom.V <- names(Sim.tot.q[i])
                  P <- P.mat[, 6]
                  
                  # Graphique des observes
                  dates.O <- O.mat[, 2:4]
                  dates.O <-
                    as.matrix(paste(dates.O[, 3], dates.O[, 2], dates.O[, 1], sep = "/"))
                  O <- O.mat[, 6]
                  temps.O <- as.Date(dates.O, format = "%d/%m/%Y")
                  
                  Vmax <- max(O, P) + 0.10 * max(O, P)
                  Vmin <- min(O, P) - 0.10 * min(O, P)
                  
                  # Calcul des min et max par variable sur l'ensemble des UMSs ayant des obs 
                  # (afin d'avoir une echelle commune pertinente pour les graphes dynamiques par variable)
                  VmaxTot[nom.V] = max(Vmax, VmaxTot[nom.V], na.rm = TRUE)
                  VminTot[nom.V] = min(Vmin, VminTot[nom.V], na.rm = TRUE)
                  
                  plot(
                    temps.P,
                    P,
                    col = "blue",
                    type = "l",
                    ylab = nom.V,
                    xlab = annee,
                    main = FinalBatchFich[q],
                    cex.main = 1.5,
                    ylim = c(Vmin, (Vmax + 0.2 * Vmax))
                  )
                  points(
                    temps.O,
                    O,
                    pch = 22,
                    col = "red",
                    bg = "yellow"
                  )
                  legend(
                    "topleft",
                    legend = c("Observed", "simulated"),
                    cex = 1 / 1.5,
                    bty = "n",
                    pch = c(22, 0),
                    lty = c(0, 1),
                    col = c("red", "blue"),
                    pt.bg = "yellow"
                  )
                  
                  # Calcul du RMSE par USM et variable
                  # nous selectionnons uniquement les lignes sans NA; i.e. celles ou nous avons des obs pour la variable
                  tabMergeNAFilter <-
                    tabMerge[complete.cases(tabMerge[, c(names(Sim.tot.q[i]), paste0(names(Obs.tot.q[j]), "obs"))]), c(names(Sim.tot.q[i]), paste0(names(Obs.tot.q[j]), "obs"))]
                  
                  residu = tabMergeNAFilter[, paste0(names(Obs.tot.q[j]), "obs")] - tabMergeNAFilter[, names(Sim.tot.q[i])]
                  
                  rmsePerUsm[FinalBatchFich[q], names(Sim.tot.q[i])] = round(((1 /length(residu)) * sum((residu) ^ 2)) ^ 0.5, 3)
                  
                }
              }
            }
          }
        }
      }
      
      invisible(dev.off())
      
      # Creation du fichier contenant les RMSE par USM et variable
      rmsePerUsm = rmsePerUsm[, apply(rmsePerUsm, 2, function(x) ! all(is.na(x)))]
      rmsePerUsm = rmsePerUsm[apply(rmsePerUsm, 1, function(x) ! all(is.na(x))), ]
      # Fichier enregistre dans le repertoire de travail
      write.table(
        rmsePerUsm,
        file.path(chficsortie, paste0("rmsePerUSM", suffix_tag, ".csv")),
        sep = ";",
        row.names = F,
        quote = F
      ) 
      
      
      if (DynPlotVarSort == 1) {
        varnames = colnames(rmsePerUsm)[2:ncol(rmsePerUsm)]
        USMnames = rownames(rmsePerUsm)
        
        # loop over variables
        for (i in 1:length(varnames)) {
          
          indNonNA = !is.na(rmsePerUsm[, varnames[i]])
          rmse = rmsePerUsm[indNonNA, varnames[i]]
          usmList = USMnames[indNonNA]
          
          sortedRMSE = sort(rmse, decreasing = TRUE, index.return = TRUE)
          
          SortedUsmList = usmList[sortedRMSE$ix]
          
          if (length(SortedUsmList) > 0) {
            # Creation d'un fichier pdf ou seront enregistrees les figures
            pdf(
              file.path(
                chficsortie,
                paste0("Graph_dynamiques_", varnames[i], suffix_tag, ".pdf")
              ),
              paper = "a4",
              width = 7,
              height = 10
            )
            par(oma = c(2, 0, 4, 0))
            par(mar = c(8, 6, 4, 4))
            par(mfrow = c(2, 1))
            
            plot(
              0,
              xaxt = 'n',
              yaxt = 'n',
              bty = 'n',
              pch = '',
              ylab = '',
              xlab = ''
            )
            text(0,
                 paste0(
                   "Number of USMs containing observations : ",
                   length(SortedUsmList)
                 ),
                 cex = 1.3)
            plot(
              0,
              xaxt = 'n',
              yaxt = 'n',
              bty = 'n',
              pch = '',
              ylab = '',
              xlab = ''
            )
            title(
              main = paste0("Dynamics plots, variable ", varnames[i], " ", eval_title),
              outer = T,
              cex.main = 1.5
            )
            # Parametres de la fenetre graphique
            par(mfrow = c(3, 2)) 
            #print(varnames)
            #stop()
            # loop over USMs
            for (q in 1:length(SortedUsmList)) {
              #print(varnames[i])
              Sim.tot.q <-
                subset(Sim.tot[, c(colnames(Sim.tot[, 1:5]), varnames[i])],
                       as.character(Sim.tot[, 1]) == SortedUsmList[q])
              Obs.tot.q <-
                subset(Obs.tot[, c(colnames(Obs.tot[, 1:5]), varnames[i])],
                       as.character(Obs.tot[, 1]) == SortedUsmList[q])
              
              P.mat <- na.omit(data.frame(Sim.tot.q))
              O.mat <- na.omit(data.frame(Obs.tot.q))
              
              
              # Axes "temps" du graphique pour simules
              dates.P <- P.mat[, 2:4]
              dates.P <-
                as.matrix(paste(dates.P[, 3], dates.P[, 2], dates.P[, 1], sep = "/"))
              annees <- as.factor(P.mat[, 2])
              alevels <- levels(annees)
              if (length(alevels) == 1) {
                annee <- paste0("year ", as.numeric(alevels[1]))
              } else
                if (length(alevels) == 2) {
                  annee <-
                    paste0("years ",
                           as.numeric(alevels[1]),
                           "-",
                           as.numeric(alevels[2]))
                }
              temps.P <- as.Date(dates.P[, 1], format = "%d/%m/%Y")
              nom.V <- names(varnames[i])
              P <- P.mat[, 6]
              
              # Graphique des observes
              dates.O <- O.mat[, 2:4]
              dates.O <-
                as.matrix(paste(dates.O[, 3], dates.O[, 2], dates.O[, 1], sep = "/"))
              O <- O.mat[, 6]
              temps.O <- as.Date(dates.O, format = "%d/%m/%Y")
              
              Sim.tot[, varnames[i]]
              
              Vmax = VmaxTot[varnames[i]]
              Vmin = VminTot[varnames[i]]
              
              plot(
                temps.P,
                P,
                col = "blue",
                type = "l",
                ylab = varnames[i],
                xlab = annee,
                main = SortedUsmList[q],
                cex.main = 1.5,
                ylim = c(Vmin, (Vmax + 0.2 * Vmax))
              )
              points(temps.O,
                     O,
                     pch = 22,
                     col = "red",
                     bg = "yellow")
              legend(
                "topleft",
                legend = c("Observed", "simulated"),
                cex = 1 / 1.5,
                bty = "n",
                pch = c(22, 0),
                lty = c(0, 1),
                col = c("red", "blue"),
                pt.bg = "yellow"
              )
              mtext(paste("RMSE:", sortedRMSE$x[q]), cex = 1 / 2)
              
            }
            invisible(dev.off())
          }
        }
      }
    }
    ##############################################################################################################################################################
    # 3- Calcul des criteres Statistiques pour comparer "Simules-Observes"																						##
    ##############################################################################################################################################################
    if (CritCalc == 1) {
      
      #initialisation pour le vecteur qui comprendra le nom des variables
      nom.Var.tot <-
        "init" 
      
      # Table de distribution de T pour alpha=5% (Pout tester si difference moyenne (M) entre simules et observes est differente de 0, au seuil alpha=5%
      Deg.lib <-
        c(
          1,
          2,
          3,
          4,
          5,
          6,
          7,
          8,
          9,
          10,
          11,
          12,
          13,
          14,
          15,
          16,
          17,
          18,
          19,
          20,
          21,
          22,
          23,
          24,
          25,
          26,
          27,
          28,
          29,
          30,
          31,
          32,
          33,
          34,
          35,
          36,
          37,
          38,
          39,
          40,
          41,
          42,
          43,
          44,
          45,
          46,
          47,
          48,
          49,
          50,
          60,
          70,
          80,
          90,
          100,
          110,
          120,
          130,
          140,
          151
        )
      t.seuils_alpha5 <-
        c(
          12.706,
          4.3027,
          3.1824,
          2.7765,
          2.5706,
          2.4469,
          2.3646,
          2.306,
          2.2622,
          2.2281,
          2.201,
          2.1788,
          2.1604,
          2.1448,
          2.1315,
          2.1199,
          2.1098,
          2.1009,
          2.093,
          2.086,
          2.0796,
          2.0739,
          2.0687,
          2.0639,
          2.0595,
          2.0555,
          2.0518,
          2.0484,
          2.0452,
          2.0423,
          2.0395,
          2.0369,
          2.0345,
          2.0322,
          2.0301,
          2.0281,
          2.0262,
          2.0244,
          2.0227,
          2.0211,
          2.0195,
          2.0181,
          2.0167,
          2.0154,
          2.0141,
          2.0129,
          2.0117,
          2.0106,
          2.0096,
          2.0086,
          2.0003,
          1.9944,
          1.9901,
          1.9867,
          1.984,
          1.9818,
          1.9799,
          1.9784,
          1.9771,
          1.96
        )
      TableT <- data.frame(cbind(Deg.lib, t.seuils_alpha5))
      
      # Nous recuperons pour chaque variable observee, le couple valeur observee vs simulee (i et j sont les indices pour les variables
      # simulee et observee respectivement)
      
      #Initialisation de la matrice qui contiendra les valeurs des criteres stat
      crit.tot <- array(0, dim = c(28, 0))
      
      for (i in 6:length(Sim.tot)) {
        for (j in 6:length(Obs.tot)) {
          if (names(Sim.tot[i]) == names(Obs.tot[j])) {
            #si la variable simulee est aussi une variable observee
            Var.P <- cbind(Sim.tot[, 1:5], Sim.tot[, i])
            Var.O <- cbind(Obs.tot[, 1:5], Obs.tot[, j])
            result <-
              merge(
                Var.P,
                Var.O,
                by.x = c("usm", "ian", "mo", "jo", "jul"),
                by.y = c("usm", "ian", "mo", "jo", "jul"),
                all.y = TRUE,
                all.x = FALSE,
                sort = FALSE
              )
            names(result) <-
              c(names(Sim.tot[1:5]),
                names(Sim.tot[i]),
                paste0(names(Sim.tot[i]), "obs"))
            
            # Couple de valeurs observees et simulees pour notre variable i
            # nous selectionnons uniquement les lignes sans NA; i.e. celles ou nous avons des obs pour la variable
            result <-
              result[complete.cases(result), ] 
            # Valeurs de la variable simulee
            P <- result[, 6] 
            # Valeurs de la variable observee
            O <- result[, 7]
            # compte le nombre d'observations pour la variable consideree
            Nb.O <-
              nrow(result) 
            # nb.usm <- as.numeric(nlevels(as.factor(result[, 1])))
            nb.usm <- length(unique(result[, 1]))
            
            # Calcul des criteres stat dans le cas ou nous avons des observations et la variable simulee
            if (Nb.O != 0) {
              nom.Var <- names(Sim.tot[i])
              nom.Var.tot <- cbind(nom.Var.tot, nom.Var)
              #Moyennes
              O.mean <- mean(O)
              P.mean <- mean(P)
              #Mean difference
              M <- mean(O - P)
              if (Nb.O > 1) {
                #Regression lineaire Obs-Sim
                resreg <- lm(P ~ O)
                Preg <- fitted.values(resreg)
                coef.cor <- summary(resreg)$adj.r.squared
                #Ecart-type
                O.sd <- sd(O)
                P.sd <- sd(P)
                #Coefficient de variation
                O.cv <- (O.sd / O.mean) * 100
                P.cv = 0
                if (P.mean > 0) {
                  P.cv <- (P.sd / P.mean) * 100
                }
              }
              #Initialisations
              sum.dif <- 0
              sum.error <- 0
              sum.error.egs <- 0
              sum.error.egu <- 0
              sum.mean.dev <- 0
              sum.mean.dev2 <- 0
              sum.mean.dev.P <- 0
              sum.error.r <- 0
              sum.sd2.num <- 0
              
              #Calcul des differences entre observes et simules
              for (k in 1:length(P)) {
                # difference entre valeur simulee et observee
                dif <- (O[k] - P[k]) 
                error <- dif ^ 2
                # erreur relative
                if (O[k] != 0) {
                  error.r <- (O[k] - P[k]) / O[k]
                } else{
                  error.r <- 0
                } 
                # pour calcul de la variance de M (mean difference)
                if (Nb.O > 1) {
                  # difference entre predit par la regression lineaire et observe
                  error.egs <-
                    (Preg[k] - O[k]) ^ 2 
                  # difference entre predit par la regression lineaire et simule
                  error.egu <-
                    (P[k] - Preg[k]) ^ 2 
                  # deviation des observes / moyenne des observes
                  mean.dev <-
                    (O[k] - O.mean) ^ 2 
                  # deviation des simules / moyenne des observes
                  mean.dev.P <-
                    (P[k] - O.mean) ^ 2 
                  sd2.num <-
                    (O[k] - P[k] - M) ^ 2
                }
                # Sommes des differences
                sum.error <- sum.error + error
                sum.error.r <- sum.error.r + error.r
                if (Nb.O > 1) {
                  sum.error.egs <- sum.error.egs + error.egs
                  sum.error.egu <- sum.error.egu + error.egu
                  sum.mean.dev <- sum.mean.dev + mean.dev
                  sum.mean.dev.P <- sum.mean.dev.P + mean.dev.P
                  sum.sd2.num <- sum.sd2.num + sd2.num
                }
              }
              
              # Calcul des Criteres statistiques
              # a measure of model accuracy; vary 0 to infini; the lower the better
              RMSE <-
                ((1 / Nb.O) * sum.error) ^ 0.5 
              # CV RMSE (%) - valeur relative
              rRMSE <- 100 * RMSE / O.mean 
              # erreur relative, un estimateur du biais de la difference totale entre simules et observes
              E <-
                (100 / Nb.O) * sum.error.r 
              if (Nb.O > 1) {
                # systematic RMSE (deviation des observes / regression lineaire)
                RMSEs <-
                  ((1 / Nb.O) * sum.error.egs) ^ 0.5 
                # CV RMSEs (%)
                rRMSEs <- 100 * RMSEs / O.mean 
                # proportion of RMSE systematic
                pRMSEs <-
                  RMSEs ^ 2 / RMSE ^ 2  
                # unsystematic RMSE (deviation des simules / regression lineaire)
                RMSEu <-
                  ((1 / Nb.O) * sum.error.egu) ^ 0.5 
                # CV RMSEu (%)
                rRMSEu <- 100 * RMSEu / O.mean 
                # proportion of RMSE unsystematic
                pRMSEu <-
                  RMSEu ^ 2 / RMSE ^ 2 
                # efficience du modele ; max 1; the closer to 1 the better
                EF <-
                  1 - sum.error / sum.mean.dev 
                EF[!is.finite(EF)] <- NA
                
                # Coefficient of determination ; the proportion of total variance in observed data that is explained in the predicted data ; lowest is 0, CD>1 good
                CD <- sum.mean.dev / sum.mean.dev.P
                
                # Test de Student M differente de 0?
                # variance de M=mean difference
                sd2 <-
                  sum.sd2.num / (Nb.O - 1) 
                # t de Student
                t.stud <- M / (sd2 / Nb.O) ^ 0.5 
                # Calcul du t.seuil pour alpha=5%
                if ((Nb.O - 1) > 140) {
                  t.seuil <- 1.96
                } else{
                  for (k in 1:49) {
                    if (TableT[k, 1] == (Nb.O - 1)) {
                      t.seuil <- TableT[k, 2]
                    }
                  }
                  for (k in 50:59) {
                    if (TableT[k, 1] <= Nb.O) {
                      if (TableT[k + 1, 1] > Nb.O) {
                        t.seuil <- TableT[k, 2]
                      }
                    }
                  }
                }
                #Comparaison tseuil et t(M)
                if (!is.na(t.stud)) {
                  if (t.stud >= 0) {
                    diffT <- t.seuil - t.stud
                    if (diffT > 0) {
                      decision <- "OK"
                    } else{
                      decision <- "rejection M=0"
                    }
                  } else
                    if (t.stud < 0) {
                      diffT <- t.seuil + t.stud
                      if (diffT > 0) {
                        decision <- "OK"
                      } else{
                        decision <- "rejection M=0"
                      }
                    }
                }
                
                #Decomposition de MSE en 3 parties
                # ecart-type corrige des simules
                P.sd2 <- P.sd * ((1 - Nb.O) / Nb.O) 
                # ecart-type corrige des observes
                O.sd2 <- O.sd * ((1 - Nb.O) / Nb.O) 
                # carre de la difference entre les valeurs moyennes obs et sim
                bias2 <- (O.mean - P.mean) ^ 2 
                # carre de la difference entre variabilite des obs et des sim
                SDSD <- (O.sd2 - P.sd2) ^ 2 
                # Residus
                LCS <- 2 * O.sd2 * P.sd2 * (1 - (abs(coef.cor)) ^ 0.5) 
                # Indices relatifs
                rbias2 <- bias2 / O.mean ^ 2
                rSDSD <- SDSD / O.mean ^ 2
                rLCS <- LCS / O.mean ^ 2
              }
              
              # Nous entrons ces valeurs dans le vecteur crit
              
              if (Nb.O == 1) {
                crit <- array(0, dim = c(28, 0))
                crit[1] <- as.numeric(round(nb.usm, 0))
                crit[2] <- 1
                crit[3] <- as.numeric(round(O.mean, 3))
                crit[4] <- as.numeric(round(P.mean, 3))
                crit[5:7] <- NA
                crit[8] <- as.numeric(round(RMSE, 3))
                crit[9] <- as.numeric(round(rRMSE, 3))
                crit[10:17] <- NA
                crit[18] <- as.numeric(round(M, 3))
                crit[19] <- as.numeric(round(E, 3))
                crit[20:28] <- NA
                crit.tot <- cbind(crit.tot, crit)
              }
              if (Nb.O > 1) {
                crit <- array(0, dim = c(28, 0))
                crit[1] <- as.numeric(round(nb.usm, 0))
                crit[2] <- as.numeric(round(Nb.O, 0))
                crit[3] <- as.numeric(round(O.mean, 3))
                crit[4] <- as.numeric(round(P.mean, 3))
                crit[5] <- round(O.cv, 0)
                crit[6] <- round(P.cv, 0)
                crit[7] <- as.numeric(round(abs(coef.cor) ^ 0.5, 3))
                crit[8] <- as.numeric(round(RMSE, 3))
                crit[9] <- as.numeric(round(rRMSE, 3))
                crit[10] <- as.numeric(round(RMSEs, 3))
                crit[11] <- as.numeric(round(rRMSEs, 3))
                crit[12] <- as.numeric(round(pRMSEs, 3))
                crit[13] <- as.numeric(round(RMSEu, 3))
                crit[14] <- as.numeric(round(rRMSEu, 3))
                crit[15] <- as.numeric(round(pRMSEu, 3))
                crit[16] <- as.numeric(round(EF, 3))
                crit[17] <- as.numeric(round(CD, 3))
                crit[18] <- as.numeric(round(M, 3))
                crit[19] <- as.numeric(round(E, 3))
                crit[20] <- as.numeric(round(t.stud, 3))
                crit[21] <- as.numeric(round(t.seuil, 3))
                crit[22] <- decision
                crit[23] <- as.numeric(round(bias2, 3))
                crit[24] <- as.numeric(round(SDSD, 3))
                crit[25] <- as.numeric(round(LCS, 3))
                crit[26] <- as.numeric(round(rbias2, 3))
                crit[27] <- as.numeric(round(rSDSD, 3))
                crit[28] <- as.numeric(round(rLCS, 3))
                crit.tot <- cbind(crit.tot, crit)
              }
            }
          }
        }
      }
      #						}
      
      # Exportation du tableau synthetisant les criteres statistiques dans un fichier csv
      dimnames(crit.tot)[[2]] <- nom.Var.tot[-1]
      dimnames(crit.tot)[[1]] <- crit_names
      critstat <- as.data.frame(crit.tot)
      critstat = critstat[, apply(critstat, 2, function(x)
        ! all(is.na(x))), drop = FALSE]
      critstat = critstat[apply(critstat, 1, function(x)
        ! all(is.na(x))), , drop = FALSE]
      # Fichier enregistre dans le repertoire de travail
      write.table(critstat, file.path(chficsortie, paste0("critstat", suffix_tag, ".csv")), sep =";") 
    }
    
    ##########################################################################################################################
    # 4- Sortie graphique des criteres statistiques																					                                 #
    ##########################################################################################################################
    
    if (CritPlot == 1) {
      # managing critstat data
      if (!exists("critstat")) {
        critstat <-
          read.csv(
            file.path(chficsortie, paste0("critstat", suffix_tag, ".csv")),
            sep = ";",
            na.strings = "NA",
            header = TRUE
          )
      }
      # matrice transposee pour les besoin du graphique
      crit <- as.data.frame(t(critstat)) 
      # nous supprimons les lignes correspondant aux variables non mesurees (NA)
      crit <- na.omit(crit) 
      # Dans le fichier .pdf suivant
      pdf(
        file.path(chficsortie, paste0("Criteres_Stats", suffix_tag, ".pdf")),
        paper = "a4",
        width = 7,
        height = 10
      ) 
      plot.new()
      par(oma = c(2, 0, 4, 0))
      par(mar = c(8, 6, 4, 4))
      title(
        main = paste0("Statistical criteria ", eval_title),
        outer = T,
        cex.main = 1.5
      )
      # 3 graphiques par page, 3 lignes et 1 colonne
      par(mfrow = c(3, 1)) 
      var.names <- row.names(crit)
      # Nombre de donnees observees
      Nb.obs <- as.numeric(as.character(t(crit[, 2])))
      barplot(
        Nb.obs,
        names.arg = var.names,
        main = "Number of observations per variable",
        cex.main = 1.2,
        axes = TRUE,
        cex.axis = 0.8,
        cex.lab = 0.6,
        col = "grey",
        cex.names = 0.8,
        las = 2
      )
      
      # Comparaison des moyennes et de la variabilite des valeurs observees et simulees
      Val.mean <-
        as.numeric(as.character(t(crit[, 4]))) * 100 / as.numeric(as.character(t(crit[, 3])))
      barplot(
        Val.mean,
        names.arg = var.names,
        main = "Ratio between mean simulated values and mean observed values (%)",
        cex.main = 1.2,
        axes = TRUE,
        cex.axis = 0.8,
        cex.lab = 0.6,
        cex.names = 0.8,
        las = 2,
        beside = TRUE
      )
      
      Val.cv1 <- as.numeric(as.character(t(crit[, 5])))
      Val.cv2 <- as.numeric(as.character(t(crit[, 6])))
      max.var <- max(Val.cv1, Val.cv2)
      Val.cv <- as.matrix(rbind(Val.cv1, Val.cv2))
      barplot(
        Val.cv,
        names.arg = var.names,
        main = "Comparison between simulated and observed coefficient of variation",
        cex.main = 1.2,
        axes = TRUE,
        cex.axis = 0.8,
        cex.lab = 0.6,
        col = c("grey", "black"),
        cex.names = 0.8,
        las = 2,
        beside = TRUE,
        ylim = c(0, (max.var + max.var * 0.2))
      )
      legend(
        "topleft",
        legend = c("Observed", "Simulated"),
        fill = c("grey", "black")
      )
      
      # Differentes RMSE
      # RMSE relative
      rRMSE <- as.numeric(as.character(t(crit[, 9])))
      barplot(
        rRMSE,
        names.arg = var.names,
        main = "Relative RMSE (%)",
        cex.main = 1.2,
        axes = TRUE,
        cex.axis = 0.8,
        cex.lab = 0.6,
        col = "grey",
        cex.names = 0.8,
        las = 2
      )
      
      # RMSE systematique et non systematique relatives
      rRMSEs <- as.numeric(as.character(t(crit[, 11])))
      rRMSEu <- as.numeric(as.character(t(crit[, 14])))
      rRMSEsu <- as.matrix(rbind(rRMSEs, rRMSEu))
      max.var <- max(rRMSEs, rRMSEu)
      barplot(
        rRMSEsu,
        names.arg = var.names,
        main = "Relative systematic and unsystematic RMSE (%)",
        cex.main = 1.2,
        axes = TRUE,
        cex.axis = 0.8,
        cex.lab = 0.6,
        col = c("light grey", "dark grey"),
        cex.names = 0.8,
        las = 2,
        beside = TRUE,
        ylim = c(0, max.var + max.var * 0.2)
      )
      legend(
        "topleft",
        legend = c("rRMSEs", "rRMSEu"),
        fill = c("light grey", "dark grey")
      )
      
      # Proportion de RMSE totale systematique et non systematique
      pRMSEs <- as.numeric(as.character(t(crit[, 12])))
      pRMSEu <- as.numeric(as.character(t(crit[, 15])))
      pRMSEsu <- as.matrix(rbind(pRMSEs, pRMSEu))
      barplot(
        pRMSEsu,
        names.arg = var.names,
        main = "Systematic and unsystematic RMSE",
        cex.main = 1.2,
        axes = TRUE,
        cex.axis = 0.8,
        cex.lab = 0.6,
        col = c("light grey", "dark grey"),
        cex.names = 0.8,
        las = 2,
        beside = FALSE,
        ylim = c(0, 1.2)
      )
      legend(
        "topleft",
        fill = c("light grey", "dark grey"),
        legend = c("pRMSEs", "pRMSEu")
      )
      
      # Efficience du modele
      EF <- as.numeric(as.character(t(crit[, 16])))
      min.var <- min(EF)
      if (min.var > 0) {
        min.var <- 0
      }
      barplot(
        EF,
        names.arg = var.names,
        main = "Model Efficiency",
        cex.main = 1.2,
        axes = TRUE,
        cex.axis = 0.8,
        cex.lab = 0.6,
        col = "grey",
        cex.names = 0.8,
        las = 2,
        ylim = c(min.var, 1)
      )
      abline(h = 1, col = "blue")
      
      # Coefficient de determination - proportion de la variance totale
      # des observees expliquee par les simulees
      CD <- as.numeric(as.character(t(crit[, 17])))
      barplot(
        CD,
        names.arg = var.names,
        main = "Coefficient of determination",
        cex.main = 1.2,
        axes = TRUE,
        cex.axis = 0.8,
        cex.lab = 0.6,
        col = "grey",
        cex.names = 0.8,
        las = 2
      )
      abline(h = 1, col = "blue")
      
      # Erreur relative (indicateur du biais)
      E <- as.numeric(as.character(t(crit[, 18])))
      barplot(
        E,
        names.arg = var.names,
        main = "Relative Error",
        cex.main = 1.2,
        axes = TRUE,
        cex.axis = 0.8,
        cex.lab = 0.6,
        col = "grey",
        cex.names = 0.8,
        las = 2
      )
      
      # Test sur le biais en l'absence de replication des donnees observees
      # Difference moyenne
      M <- as.numeric(as.character(t(crit[, 19])))
      barplot(
        M,
        names.arg = var.names,
        main = "Observed-simulated mean difference",
        cex.main = 1.2,
        axes = TRUE,
        cex.axis = 0.8,
        cex.lab = 0.6,
        col = "grey",
        cex.names = 0.8,
        las = 2
      )
      
      # t de Student
      tM <- as.numeric(as.character(t(crit[, 20])))
      tseuil <- as.numeric(as.character(t(crit[, 21])))
      barplot.t <-
        barplot(
          tM,
          names.arg = var.names,
          main = "T student test of the mean difference (M)",
          cex.main = 1.2,
          axes = TRUE,
          cex.axis = 0.8,
          cex.lab = 0.6,
          col = "grey",
          cex.names = 0.8,
          las = 2
        )
      #ajouter t.seuil>0 a critstat
      points(x = barplot.t, y = tseuil, col = "blue")
      #ajouter t.seuil<0 a critstat
      points(x = barplot.t,
             y = -tseuil,
             col = "blue")
      
      # Decomposition de la MSE - indices relatifs (divises par la moyennee)
      bias2 <- as.numeric(as.character(t(crit[, 26])))
      SDSD <- as.numeric(as.character(t(crit[, 27])))
      LCD <- as.numeric(as.character(t(crit[, 28])))
      Sum <- rbind(bias2, SDSD, LCD)
      Sum <- colSums(na.omit(Sum))
      max.sum <- max(Sum)
      MSEdecomp <- as.matrix(rbind(bias2, SDSD, LCD))
      barplot(
        MSEdecomp,
        names.arg = var.names,
        main = "MSE Decomposition",
        cex.main = 1.2,
        ylim = c(0, max.sum + max.sum * 0.2),
        axes = TRUE,
        cex.axis = 0.8,
        cex.lab = 0.6,
        col = c("black", "grey", "white"),
        cex.names = 0.8,
        las = 2,
        beside = FALSE
      )
      legend(
        "topleft",
        fill = c("black", "grey", "white"),
        legend = c("rbiase", "rSDSD", "rLCD")
      )
      
      invisible(dev.off())
    }
    
    ##############################################################################################################################################################
    # 5- Dessiner des graphiques Sim-Obs en mettant en commun toutes les usm et toutes les dates - par variable ou nous avons des observes  					##
    ##############################################################################################################################################################
    
    if (ScatterPlot == 1) {
      # Creation d'un fichier pdf ou seront enregistrees les figures
      pdf(
        file.path(chficsortie, paste0("Graph_Obs-Sim", suffix_tag, ".pdf")),
        paper = "a4",
        width = 7,
        height = 10
      )
      par(pty = "s")
      # Parametres de la fenetre graphique
      plot.new()
      par(oma = c(2, 0, 4, 0))
      par(mar = c(8, 6, 4, 4))
      title(
        main = paste0("Observed-Simulated plots ", eval_title),
        outer = T,
        cex.main = 1.5
      )
      par(mfrow = c(3, 2))
      
      # Nous recuperons pour chaque variable observee, le couple valeur observee vs simulee (i et j sont les indices pour les variables
      # simulee et observee respectivement)
      
      for (i in 6:ncol(Sim.tot)) {
        for (j in 6:ncol(Obs.tot)) {
          if (names(Sim.tot[i]) == names(Obs.tot[j])) {
            #si la variable simulee est aussi une varibale observee
            Var.P <- cbind(Sim.tot[, 1:5], Sim.tot[, i])
            Var.O <- cbind(Obs.tot[, 1:5], Obs.tot[, j])
            result <-
              merge(
                Var.P,
                Var.O,
                by.x = c("usm", "ian", "mo", "jo", "jul"),
                by.y = c("usm", "ian", "mo", "jo", "jul"),
                all.y = TRUE,
                all.x = FALSE,
                sort = FALSE
              )
            names(result) <-
              c(names(Sim.tot[1:5]),
                names(Sim.tot[i]),
                paste0(names(Sim.tot[i]), "obs"))
            nom.Var <- names(Sim.tot[i])
            
            # Couple de valeurs observees et simulees pour notre variable i
            # nous selectionnons uniquement les lignes sans NA; i.e. celles ou nous avons des obs pour la variable
            result <- result[complete.cases(result), ] 
            # Valeurs de la variable simulee
            P <- result[, 6] 
            # Valeurs de la variable observee
            O <- result[, 7] 
            # compte le nombre d'observations pour la variable consideree
            Nb.O <- nrow(result) 
            nom.usm <- result[, 1]
            
            if (Nb.O != 0) {
              # Definir les limites pour l'echelle des graphiques
              max <- max(P, O)
              min <- min(P, O)
              
              # Dessiner le graphique
              plot(
                O,
                P,
                xlab = paste(nom.Var, "obs"),
                ylab = paste(nom.Var, "sim"),
                pch = 22,
                col = "black",
                bg = "grey",
                xlim = c(min, max),
                ylim = c(min, max),
                pty = "s"
              )
              
              # Ajout de la 1ere diagonale
              abline(0, 1, lty = 2)
              
              # Ajout de la droite de regression, si plus d'un point
              if (length(P) > 1) {
                # Modele de regression lineaire
                reg.lin <- lm(P ~ O)
                # Tracage de la droite, si
                
                if (all(!is.na(reg.lin$coefficients))) {
                  abline(reg.lin, col = "blue")
                }
                
                
                # Recuperer les coefficients de regression
                coeff <- reg.lin$coef
                coef.cor <- summary(reg.lin)$adj.r.squared
                
                # Inscription sur le graphique des parametres de la regression
                text(
                  min * 0.97,
                  max - (max - min) * 0.06,
                  paste("Intercept :", round(coeff[1], 2)),
                  pos = 4,
                  cex = 0.75
                )
                text(
                  min * 0.97,
                  max - (max - min) * 0.12,
                  paste("Slope :", round(coeff[2], 2)),
                  pos = 4,
                  cex = 0.75
                )
                text(
                  min * 0.97,
                  max - (max - min) * 0.18,
                  paste("R squared :", round(coef.cor, 2)),
                  pos = 4,
                  cex = 0.75
                )
              }
              # Ajout du nom des usms sur les points du graphique
              #	text(P, O, nom.usm,cex=0.3, col="black")
              
              # managing critstat data
              if (!exists("critstat")) {
                critstat <-
                  read.csv(
                    file.path(
                      chficsortie,
                      paste0("critstat", suffix_tag, ".csv")
                    ),
                    sep = ";",
                    na.strings = "NA",
                    header = TRUE
                  )
              }
              crit <- as.data.frame(critstat)
              for (x in 1:length(crit)) {
                if (names(crit[x]) == nom.Var) {
                  crit.var <- (crit[, x])
                }
              }
              
              mtext(paste(
                "MD:",
                crit.var[18],
                "  NRMSE:",
                crit.var[9],
                "  Eff:",
                crit.var[16]
              ),
              cex = 1 / 2)
            }
          }
        }
      }
      
      invisible(dev.off())
      
      # Graphe sur les residus
      # Creation d'un fichier pdf ou seront enregistrees les figures
      pdf(
        file.path(chficsortie, paste0("Graph_Res-Obs", suffix_tag, ".pdf")),
        paper = "a4",
        width = 7,
        height = 10
      )
      # Parametres de la fenetre graphique
      plot.new()
      par(oma = c(2, 0, 4, 0))
      par(mar = c(8, 6, 4, 4))
      #title(main=paste0("Graphiques Residus de la BDD ", title),outer=T,cex.main=1.5)
      title(
        main = paste0("Residues plots ", eval_title),
        outer = T,
        cex.main = 1.5
      )
      par(mfrow = c(3, 2))
      
      # Nous recuperons pour chaque variable observee, le couple valeur observee vs simulee (i et j sont les indices pour les variables
      # simulee et observee respectivement)
      for (i in 6:ncol(Sim.tot)) {
        for (j in 6:ncol(Obs.tot)) {
          if (names(Sim.tot[i]) == names(Obs.tot[j])) {
            #si la variable simulee est aussi une varibale observee
            Var.P <- cbind(Sim.tot[, 1:5], Sim.tot[, i])
            Var.O <- cbind(Obs.tot[, 1:5], Obs.tot[, j])
            result <-
              merge(
                Var.P,
                Var.O,
                by.x = c("usm", "ian", "mo", "jo", "jul"),
                by.y = c("usm", "ian", "mo", "jo", "jul"),
                all.y = TRUE,
                all.x = FALSE,
                sort = FALSE
              )
            names(result) <-
              c(names(Sim.tot[1:5]),
                names(Sim.tot[i]),
                paste0(names(Sim.tot[i]), "obs"))
            nom.Var <- names(Sim.tot[i])
            
            # Couple de valeurs observees et simulees pour notre variable i
            # nous selectionnons uniquement les lignes sans NA; i.e. celles ou nous avons des obs pour la variable
            result <- result[complete.cases(result), ] 
            # Valeurs de la variable simulee
            P <- result[, 6] 
            # Valeurs de la variable observee
            O <- result[, 7] 
            Res <- O - P
            # compte le nombre d'observations pour la variable consideree
            Nb.O <- nrow(result) 
            nom.usm <- result[, 1]
            
            if (Nb.O != 0) {
              # Definir les limites pour l'echelle des graphiques
              #   max<-max(Res,O)
              #    min<-min(Res,O)
              
              # Dessiner le graphique
              plot(
                O,
                Res,
                xlab = paste(nom.Var, "obs"),
                ylab = paste(nom.Var, "residues"),
                pch = 22,
                col = "black",
                bg = "grey",
                xlim = c(min(O), max(O)),
                ylim = c(min(Res), max(Res))
              )
              
              # Ajout de la droite horizontale
              abline(h = 0, lty = 2)
              
              # Ajout de la droite de regression, si plus d'un point
              if (length(Res) > 1) {
                # Modele de regression lineaire
                reg.lin <- lm(Res ~ O)
                # Tracage de la droite, si
                
                if (all(!is.na(reg.lin$coefficients))) {
                  abline(reg.lin, col = "blue")
                }
                
                
                # Recuperer les coefficients de regression
                coeff <- reg.lin$coef
                coef.cor <- summary(reg.lin)$adj.r.squared
                
                # Inscription sur le graphique des parametres de la regression
                maxY <- max(Res)
                minY <- min(Res)
                minX <- min(O)
                text(
                  minX * 0.97,
                  maxY - (maxY - minY) * 0.06,
                  paste("Intercept :", round(coeff[1], 2)),
                  pos = 4,
                  cex = 0.75
                )
                text(
                  minX * 0.97,
                  maxY - (maxY - minY) * 0.12,
                  paste("Slope :", round(coeff[2], 2)),
                  pos = 4,
                  cex = 0.75
                )
                text(
                  minX * 0.97,
                  maxY - (maxY - minY) * 0.18,
                  paste("R squared :", round(coef.cor, 2)),
                  pos = 4,
                  cex = 0.75
                )
              }
              # Ajout du nom des usms sur les points du graphique
              #  text(P, O, nom.usm,cex=0.3, col="black")
              
              # managing critstat data
              if (!exists("critstat")) {
                critstat <-
                  read.csv(
                    file.path(
                      chficsortie,
                      paste0("critstat", suffix_tag, ".csv")
                    ),
                    sep = ";",
                    na.strings = "NA",
                    header = TRUE
                  )
              }
              crit <- as.data.frame(critstat)
              for (x in 1:length(crit)) {
                if (names(crit[x]) == nom.Var) {
                  crit.var <- (crit[, x])
                }
              }
              
              mtext(paste(
                "MD:",
                crit.var[18],
                "  NRMSE:",
                crit.var[9],
                "  Eff:",
                crit.var[16]
              ),
              cex = 1 / 2)
            }
          }
        }
      }
      invisible(dev.off())
    }
    
    print("End of processing.")
    
  }
