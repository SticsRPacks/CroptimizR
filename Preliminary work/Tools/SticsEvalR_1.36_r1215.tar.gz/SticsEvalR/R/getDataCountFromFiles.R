getDataCountFromFiles <- function(files_list=c()){
  # @title Extracting a matrix of data counts per variable for a files list
  # @param files_list List of files (obs or sti)
  # @return A matrix od data counts per usm (row) and variable (col)
  # get the data sums matrix of the first file
  
  if (is.list(files_list)){
    files_list=unlist(files_list)
  }
  prev_data = getData(files_list[1])$number
  
  if (length(files_list) > 1){
    for (i in 2:length(files_list)){
      # get the data sums matrix of the current file
      current_data = getData(files_list[i])$number
      # merging prev_data with tmp_
      tmp=merge(prev_data,current_data,all.x=TRUE,all.y=TRUE,sort=FALSE)
      # setting row names (valid syntax : because merge unsorted !!)
      row.names(tmp) <- c(row.names(prev_data),row.names(current_data))
      prev_data=tmp
    }
  }
  return(prev_data)
}