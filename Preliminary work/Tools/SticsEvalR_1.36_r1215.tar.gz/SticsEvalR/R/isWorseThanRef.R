#
# Compare statistical criteria extracted from 2 critstat_eval files (among which one is identified to be the reference) for all variables and 
# return TRUE if any of their relative difference is considered to be a bad behavior (with respect to a given threshold and way of variation), 
# FALSE otherwise
# flagInf : TRUE if new stat criterion inferior to reference one is considered to be a good behavior
isWorseThanRef<-function(critstatRefPath,critstatNewPath,critName="RMSE",RelThreshold=5,flagInf=TRUE,comp_title="",
                         save=TRUE,rmsePerUsmRefPath="",rmsePerUsmNewPath="", UsmMetadataPath="", outputPath="",
                         varListFilter=list()){
  
  # Setting comp_title content for using it as file name suffix !
  if (comp_title!="" && gregexpr("_",comp_title)[[1]][1]!=1) {
    comp_title=paste0("_",comp_title)
  }
  
  # Setting output path
  if (outputPath=="") {
    outputPath = dirname(critstatNewPath)
  }
  
  # Reading criteria tables
  critstatRef<-try(read.table(critstatRefPath,header=T, dec=".",sep=";",na.strings = c(NA,"NaN","OK","rejection M=0")),TRUE)
  if (is(critstatRef,"try-error")) {
    stop(paste0("Reference criteria file could not be loaded: ",critstatRefPath))
  }
  critstatNew<-try(read.table(critstatNewPath,header=T, dec=".",sep=";",na.strings = c(NA,"NaN","OK","rejection M=0")),TRUE)
  if (is(critstatNew,"try-error")) {
    stop(paste0("New criteria file could not be loaded: ",critstatNewPath))
  }
  
  # Extracting common variables names from names(critstatRef) & names(critstatNew)
  # and warning telling if missing variables, and in which data.frame
  common_names=intersect(tolower(names(critstatRef)),tolower(names(critstatNew)))
  
  # Getting only selected variables if varListFilter is given in inputs
  if (length(varListFilter)>0){
    tolower_list=tolower(make.names(varListFilter))
    # checking if all var in list are in common_names first + warning
    unfound_var=unlist(setdiff(tolower_list,common_names))
    if (length(unfound_var)>0){
      print(unfound_var)
      warning("The varListFilter contains variables not found in critstat variables !")
    }
    common_names=intersect(common_names,tolower_list)
  }
  
  # Warning: if missing variables in New criteria table
  if(!length(varListFilter) & length(names(critstatRef)) > length(common_names)){
    warning(paste0("Missing variables in criterion table: ",critstatNewPath))
  }
  
  # Raising an error if empty names intersect 
  if(length(common_names)==0){
    stop("Not any common variable names in criteria tables ! Stopping.")
  }
  
  # Columns index calculation
  # TODO: if only one var : col and row names are dropped !
  # how to keep / set names ??
  ref_cols=sapply(common_names,function(x) which(is.element(tolower(names(critstatRef)),x)))
  new_cols=sapply(common_names,function(x) which(is.element(tolower(names(critstatNew)),x)))
  
  # Calculating relative difference of criteria over common variables
  diffRel<-(critstatNew[critName,new_cols]-critstatRef[critName,ref_cols])*100/critstatRef[critName,ref_cols]
  
  # isWorthThanRef result
  if(flagInf) {
    # if good behavior = crit_NEW < crit_REF then a bad behavior is (crit_NEW-crit_REF)/crit_REF > absThreshold
    critAll=diffRel>RelThreshold  
  } else {
    # if good behavior = crit_NEW > crit_REF then a bad behavior is (crit_NEW-crit_REF)/crit_REF < -absThreshold
    critAll=diffRel<(-RelThreshold)
  }
  
  # Filtering NaN and NA
  # NaN is produced when critstatRef[critName,]==0, diffRel values are infinite so replaced with NaN
  critAll[is.na(critAll)]=FALSE
  crit=any(critAll)
  
  # Creating a list with results to be returned
  res=list(isWorseThanRef=crit, diffRel=diffRel, critstatRef=critstatRef[critName,ref_cols],critstatNew=critstatNew[critName,new_cols])
  
  # Saving results in a RData file
  if (save){
    date_str=format(Sys.time(), "%Y-%m-%d_%H-%M-%S")
    outfile=file.path(outputPath,paste0("critstat_comparison",comp_title,".RData"))
    save(date_str,critstatRefPath,critstatNewPath,res,critName,RelThreshold,flagInf,file=outfile)
  }
  
  # If files detailing rmse per USM are provided, the list of USMs on which the RMSE is deteriorated is computed and returned
  if(crit & rmsePerUsmRefPath!="" & rmsePerUsmNewPath!=""){
    
    # Reading criteria per USM tables
    rmsePerUsmRefPath<-read.table(rmsePerUsmRefPath,header=T, dec=".",sep=";",na.strings = c(NA,"NaN"))
    rmsePerUsmNewPath<-read.table(rmsePerUsmNewPath,header=T, dec=".",sep=";",na.strings = c(NA,"NaN"))
    
    # For each deteriorated variable 
    listVar=common_names[critAll]
    
    for (i in 1:length(listVar)){
      
      # USMs are sorted by descending deterioration order
      relDiff=(rmsePerUsmNewPath[,listVar[i]]-rmsePerUsmRefPath[,listVar[i]])*100/rmsePerUsmRefPath[,listVar[i]]
      indNonNA=!is.na(relDiff)
      relDiff=relDiff[indNonNA]
      rmsePerUsmNewPathVari=rmsePerUsmNewPath[indNonNA,listVar[i]]
      rmsePerUsmRefPathVari=rmsePerUsmRefPath[indNonNA,listVar[i]]
      usmList=rmsePerUsmNewPath[indNonNA,1]
      
      sortedRelDiff=sort(relDiff,decreasing=TRUE, index.return = TRUE)
      
      ind=sortedRelDiff$ix[sortedRelDiff$x>0]
      
      # Building the table to be returned
      tmp = as.data.frame(matrix(ncol=4, nrow=length(ind)))
      colnames(tmp) = c("USMS","RMSE relative difference (%)","RMSE NEW","RMSE REF")
      rownames(tmp) = usmList[ind]
      tmp[,"USMS"]=usmList[ind]
      tmp[,"RMSE relative difference (%)"] = relDiff[ind]
      tmp[,"RMSE NEW"] = rmsePerUsmNewPathVari[ind]
      tmp[,"RMSE REF"] = rmsePerUsmRefPathVari[ind]
      
      # Add the corresponding USM metadata if provided
      if(UsmMetadataPath!="") {
        UsmMetadata<-read.csv(UsmMetadataPath,header=T, sep=";",stringsAsFactors = FALSE)
        rownames(UsmMetadata)=UsmMetadata[,"usm"]
        tmp=cbind(tmp,UsmMetadata[rownames(tmp),colnames(UsmMetadata)[c(-1)]])
      }
      # Writing file in the workspace directory
      write.table(tmp,file.path(outputPath,paste0("DeterioratedUsms_",listVar[i],".csv")),sep=";",row.names=F,quote=F) 
      
    }
  }
  return(res)
}