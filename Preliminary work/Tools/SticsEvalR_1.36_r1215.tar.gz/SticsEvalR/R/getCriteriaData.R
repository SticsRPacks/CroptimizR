getCriteriaData <- function(criteria_file = NULL) {
  # @param criteria_file csv file containing criteria names and definitions
  
  # TODO : defining the csv file (see xls file in man directory)
  # loading data
  
  if(is.null(criteria_file)) { 
    # List of criteria
    crit_names <- c("number-of-usm",
                    "number-of-observations",
                    "mean-of-measurements",
                    "mean-of-simulations",
                    "CV-measurements",
                    "CV-simulations",
                    "correlation-coefficient (r)",
                    "RMSE",
                    "rRMSE (%)",
                    "RMSEs",
                    "rRMSEs (%)",
                    "pRMSEs",
                    "RMSEu",
                    "rRMSEu (%)",
                    "pRMSEu",
                    "Model-efficiency (EF)",
                    "Coefficient -determination (CD)",
                    "Mean-difference (M)",
                    "Relative error (%)",
                    "Student's t (test M)",
                    "tseuil",
                    "decision",
                    "bias2 (MSE-decomp.)",
                    "SDSD(MSE-decomp.)",
                    "LCS(MSE-decomp.)",
                    "rbias2",
                    "rSDSD",
                    "rLCS"
    )
    criteria_data = data.frame(names=crit_names, stringsAsFactors = FALSE)
  }
  
  
  
  
  return(criteria_data)
}