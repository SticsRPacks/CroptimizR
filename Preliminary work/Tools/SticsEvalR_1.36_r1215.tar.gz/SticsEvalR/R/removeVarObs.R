# function for removing variables columns from observation files
removeVarObs<-function(UsmList,datapath,varObs,flagFolderPerUSM=FALSE) {
  
  # Boucle sur les USMs
  for (i in 1:length(UsmList)) {
    
    usm_name=UsmList[i]
    
    if (flagFolderPerUSM) {
      obs_path=file.path(datapath,usm_name,paste0(usm_name,".obs"))
    } else {
      obs_path=file.path(datapath,paste0(usm_name,".obs"))
    }
    
    # if usm observation file doesn't exist
    if (!file.exists(obs_path)) {
      stop(paste0("Observation file doesn't exist: ", obs_path))
    }
    
    # try reading observation file
    Obs<-try(read.table(obs_path,header=F, stringsAsFactors=FALSE,dec=".",sep=";",strip.white=TRUE),TRUE)
    
    # if reading error, next usm
    if (is(Obs, "try-error")) {
      warning(paste0("Observation file could not be loaded: ", obs_path))
      next
    }
    
    # if common variables names, doing selection
    com_var=intersect(as.vector(t(Obs[1,])),varObs)
    if (length(com_var) >0 ) {
      idx_var=com_var==Obs[1,]
      write.table(Obs[,!idx_var],obs_path,sep=";",col.names=F, row.names=F,quote=F)
      print(usm_name)
    }
  }
}