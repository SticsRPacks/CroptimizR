getFileExt <- function(file_path){
  # Getting file extension if any
  # @file_path: relative or absolute file path
  # @value: extension name without dot or emtpty string 
  #
  file_ext=""
  dot_split_strs = unlist(strsplit(basename(file_path),"\\."))
  strs_nb = length(dot_split_strs)
  
  if ( strs_nb > 1 ){
    file_ext = dot_split_strs[strs_nb]
  }
  
  return(file_ext)
}