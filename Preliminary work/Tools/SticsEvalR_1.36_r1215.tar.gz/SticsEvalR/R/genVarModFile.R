genVarModFile <- function(var_names,file_dir=NULL) {
  # @title Generation of the Stics var.mod file
  # @param var_names List or character vector of Stics variables names
  # @param file_dir File directory destination (optional)
  
  if (is.list(var_names)) {
    var_names=unlist(var_names)
  }
  file_path="var.mod"
  if (!is.null(file_dir)){
    file_path=file.path(file_dir,file_path)
  }
  varmod <- file(file_path,"w")
  writeLines(var_names,con=varmod)
  close(con = varmod)
}