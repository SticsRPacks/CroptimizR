getFileVarNames <- function(file_name){
  # @title Getting Stics variables names from a file (obs,sti)
  # @return A vector of variable names
  return (getData(file_name)$names)
  }