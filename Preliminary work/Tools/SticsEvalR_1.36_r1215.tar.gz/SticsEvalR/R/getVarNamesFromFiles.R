getVarNamesFromFiles <- function(files_list=c()){
  # @title Getting variables names for a list of files
  # @return A vector of variables names
  count_mat=getDataCountFromFiles(files_list)
  return(colnamesToVar(colnames(count_mat)))
}