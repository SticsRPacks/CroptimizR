getInitVarNames <- function(R_varnames = FALSE,to_lower = FALSE) {
  # @title Getting Stics init variables
  # @description Getting the list of initialization variables of Stics
  # @param R_varnames Transforming character string of init variables names 
  # into valid R names if TRUE, FALSE otherwise
  # @param to_lower Transforming strings to lower characters if TRUE, FALSE otherwise
  stics_init_vars <- c("HR(1)",
                       "HR(2)",
                       "HR(3)",
                       "HR(4)",
                       "HR(5)",
                       "resmes",
                       "AZnit(1)",
                       "AZnit(2)",
                       "AZnit(3)",
                       "AZnit(4)",
                       "AZnit(5)",
                       "azomes")
  if (R_varnames){
    init_names = varnamesToCol(stics_init_vars)
  } else {
    init_names = stics_init_vars
  }
  if (to_lower){
    init_names = tolower(init_names)
  }
  return(init_names)
}