colnamesToVar <- function(names_list=c()){
  # @title Convert column names strings to Stics variables names
  # @param names_list list of data.frame, matrix column names 
  # @return Corresponding Stics variables names to column names
  return(gsub("[.]","(",gsub("[.]$",")",names_list)))
  
}