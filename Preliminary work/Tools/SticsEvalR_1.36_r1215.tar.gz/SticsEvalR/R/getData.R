getData <- function( file_name, file_type=NULL ){
  # @title Extracting data from Stics files (obs, daily outoputs .sti)
  # @description Getting date, calculating data number per variable and variables names list
  # @return A named list with $usm (usm name) $table (a tibble), $names (Stics variables), $number (count per variable)
  #  
  
  require(dplyr)
  
  data_types=c("obs","sti")
  type_not_matching = FALSE
  
  # checking file
  if (!file.exists(file_name)){
    stop(paste0("File not found: ",file_name))
  }
  
  # get file extension
  data_type=getFileExt(file_name)
  
  # checking file type if given as argument
  if (!is.null(file_type)) {
    type_not_matching = !(file_type == data_type)
  }
  
  if(type_not_matching) {
    stop(paste0("File extension is not of the expected type : found ",data_type,"\n instead of ",file_type))
  }
  
  # checking if it's a known type
  if (! is.element(data_type,data_types)) {
    stop(paste0("Unknown file extension : ",data_type))
  }
  
  # creating an empty list
  data=list()
  # getting usm name for each kind of file
  switch(data_type,
         obs={data$usm=gsub(pattern = "\\.obs$","", basename(file_name))},
         sti={data$usm=gsub(pattern="mod_s","",gsub(pattern = "\\.sti$","", basename(file_name)))}
  )
  data$type <- data_type
  data$table <- as.tbl(read.csv(file_name,sep=";",stringsAsFactors = FALSE, dec=".", na.strings = c("NA"),strip.white = TRUE)) 
  # selecting only var columns
  # replacing NA values with -999.99 (is it possible ?)
  data$table[is.na(data$table)] <- -999.99
  tmp = data$table %>% select(-ian,-mo,-jo,-jul)
  # restoring original variables names from column names
  data$names= tmp %>% colnames() %>% colnamesToVar()
  # getting data number per var
  # counts per variable
  data$number= (tmp > -999.99) %>% colSums() %>% t()
  row.names(data$number) <- data$usm
  
  return(data)
  
}