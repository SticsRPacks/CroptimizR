data_table = read.table("./tests/data/obs_with_usm_col.csv",stringsAsFactors = FALSE, sep = ";",header = TRUE)

init_year = 2004 
init_jul = 281

varInit = getInitVarNames(R_varnames = TRUE,to_lower = TRUE)

IndexData = (data_table[, "jul"] == init_jul &
                  data_table[, "ian"] == init_year)

replaceDataValues(Obs,rows.index = IndexObsInit,col.names = varInit,values = 200)


replaceObsValues(Obs,rows.index = IndexDataInit,col.names = varInit,values = 1:10)
# attention remplissage par colonne si plusieurs lignes et duplication vecteur 
# valeurs si pas assez de valeurs
replaceDataValues(data_table,rows.index = 1:2,col.names = varInit,values = 1:10)
