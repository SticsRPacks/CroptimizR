replaceDataValues <- function(data_table, rows.index, col.names, values) {
  
  #IndexObsInit = (Obs[, "jul"] == Sim[1, "jul"] &
  #                  Obs[, "ian"] == Sim[1, "ian"])
  
  # testing if rows.index is logical or numeric
  replace_data = FALSE
  if (is.numeric(rows.index) & !is.null(rows.index)){
    replace_data = TRUE
    rows_num = length(rows.index)
  }
  if (is.logical(rows.index)) {
    replace_data = any(rows.index)
    rows_num = sum(rows.index)
  }
  
  # print(replace_data)

  
  if (replace_data) {
   # calculating columns index
    col_idx = is.element(colnames(data_table),col.names)
    values_nb = sum(col_idx)*rows_num
    # TODO : testing if input arg values contains enough elements for values_nb 
    print(col_idx)
    # if any varname in data_table table, setting values to NA 
    if(any(col_idx)) {
      data_table[rows.index, col_idx] = values
    }
    print(data_table)

    
    
  }
}