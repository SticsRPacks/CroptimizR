library(dplyr)
library(Classes)

# add 2 columns of zeros to climatic files
files_list=list.files(".",glob2rx("*.????"))

for (i in 1:length(files_list)){
  fname=files_list[i]
  if (!file.exists(paste0(fname,".ori"))){
    file.copy(fname,paste0(fname,".ori"))
  }
  
  tb=as.tbl(read.table(file = fname,header = FALSE))
  
  tb=mutate(tb,V14=0,V15=0)
  
  write.table(tb,file=fname,quote = FALSE,row.names=FALSE,col.names = FALSE)
}
