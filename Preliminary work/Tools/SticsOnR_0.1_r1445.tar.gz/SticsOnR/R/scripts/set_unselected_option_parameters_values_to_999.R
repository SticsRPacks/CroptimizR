xml_path="/home/plecharpent/Work/workspace/Example_Stics_Tests/R/SticsOnR/R/data/baresoil_plt.xml"

# getting options param names
param_names=get_options_names(xml_path)
# getting options values of non selected choices

# getting values of selected choice
sel_values=get_param_values(xml_path,param_names)
# getting possible choices values
all_values=get_options_choices(xml_path,param_names)

# diff between selected values and all possible values
unsel_values=vector("list",length(sel_values))
for (n in 1:length(sel_values)){
  unsel_values[[n]]=setdiff(all_values[[n]],sel_values[n])
}

# replacing parameters values of unselected choices
# for each option , get parameters names from choices values
# and replace the parameters values with -999





# see for applying parameter values replacement related to cultivar

