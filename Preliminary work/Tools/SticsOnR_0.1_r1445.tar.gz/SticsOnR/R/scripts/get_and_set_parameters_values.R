xml_path="./R/data/baresoil_plt.xml"
param_name=c("codetemp")
xml_doc=xmldocument(xml_path)

get_param_value(xml_doc,param_name,"option")

set_param_value(xml_doc,param_name,"option","2")

get_param_value(xml_doc,param_name,"option")

saveXmlDoc(xml_doc,"./R/data/baresoil_new_plt.xml")
