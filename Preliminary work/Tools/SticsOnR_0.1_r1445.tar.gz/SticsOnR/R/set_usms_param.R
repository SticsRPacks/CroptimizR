set_usms_param <- function(xml_doc_object, usms_param, overwrite = FALSE) {
  #' @export
  #'


  if ( ! "data.frame" %in% class(usms_param) ) {
    stop("usms_param do not belong to data.frame class/type")
  }

  if (! "xmlDocument" %in% class(xml_doc_object) ) {
    stop("xml_doc_object is not an XMLDocument object")
  }





  # detecting usm names column
  in_params <- names(usms_param)
  usm_col <- grep("^usm",in_params, value = T)
  in_usms_names <- usms_param[[usm_col]]

  if ( length(usm_col) == 0 || length(usm_col) > 1 ) {
    stop("No usm names column detected, or multiple columns with \"usm\" prefix")
  }

  # checking usms based on names if overwrite == FALSE
  if ( ! overwrite ) {
    # getting usm names
    xml_usms <- as.vector(get_param_value(xml_doc_object,"usm"))
    usms_idx <- is.element(in_usms_names, xml_usms)

    if (! all(usms_idx) ) {
      stop("Not any existing usms in xml file")
    }
    # filtering data in usms_param from usms_idx and ordering
    # as in xml_usms ???
    stop("Updating content of xml doc is not already implemented !")



  } else {
    # setting usms names
    set_param_value(xml_doc_object,"usm",usms_param[[usm_col]])
    usms_idx <- 1:length(in_usms_names)
  }


  # Managing parameter values replacement from usms_param
  # data.frame




  # Getting param names linked to plante node
  plante_params <- grep("_[0-9]*$",in_params, value = T)
  plante_params_pref <- unique(gsub("_[0-9]*$","",plante_params))
  for (i in 1:2) {
    for (p in plante_params_pref){
      par <- paste0(p,"_",i)
      if (is.element(par,plante_params)) {
        set_param_value(xml_doc_object,p,usms_param[[par]],"plante",as.character(i))
      }
    }
  }

  # Getting independant params from plante
  other_params <- setdiff(in_params, c(plante_params,usm_col))
  # setting param values
  for (p in other_params) {
    set_param_value(xml_doc_object,p,usms_param[[p]])
  }

}
