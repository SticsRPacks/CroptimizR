get_params_values <- function(xml_doc_objects,param_names_list,
                              parent_name = NULL, parent_sel_attr = NULL){
  #' @title Getting parameter values from xmlDocument objects
  #'
  #' @description Extracting parameter values for a list of xmlDocument and
  #' of parameters
  #'
  #' @param xml_doc_objects an xmlDocument object, or a vector/list of
  #' @param param_names_list parameter names list (i.e.: option parameter name, parameter name,
  #' other kinds in ini and some tec parameters not taken into account for the moment)
  #'
  #' @return A list of parameter list length, with parameters values for each xmlDocument
  #'
  #' @examples
  #' get_params_values(xmldoc,"codetemp")
  #' get_params_values(c(xmldoc,xmldoc2),"codetemp")
  #' get_params_values(xmldoc,c("codetemp","codegdh"))
  #' get_params_values(c(xmldoc,xmldoc2),c("codetemp","codegdh"))
  #'
  #' @export
  #'
  # ----------------------------------------------------------------------
  #  MODIFICATIONS (last commit)
  #  $Date: 2019-06-19 10:32:46 +0200 (mer. 19 juin 2019) $
  #  $Author: plecharpent $
  #  $Revision: 1442 $
  # ----------------------------------------------------------------------


  if (class(xml_doc_objects) =="xmlDocument") {
    xml_doc_objects <- list(xml_doc_objects)
  }


  if (! is.null(parent_name)) {
    param_names_list <- lapply(param_names_list,
                               function(x) c(x,parent_name,
                                             parent_sel_attr))
  }
  if ( ! is.list(param_names_list) && is.vector(param_names_list) ) {
    param_names_list <- as.list(param_names_list)
  }

  params_nb <- length(param_names_list)
  values <- vector("list", params_nb)
  for (i in 1:params_nb) {
    values[[i]]$name <- param_names_list[[i]]
    values[[i]]$values <- lapply(xml_doc_objects,
                                 function(x) get_param_value(x,param_names_list[[i]]))
  }

  # for checking names
  # return(list(names = param_names_list, values  ))
  # if ( length(values) == 1 ) {
  #   values <- unlist(values)
  # }

  return(values)
}
