get_params_types <- function(xml_doc, param_names) {
  #' @export
  #'
  #'

  # returning basic types, if call with no arguments
  if ( !nargs()) {
    return(get_param_type())
  }

  if (is.vector(param_names)) {
    param_names <- list(param_names)
  }
  return(lapply(param_names, function(x) get_param_type(xml_doc,x)))
}
