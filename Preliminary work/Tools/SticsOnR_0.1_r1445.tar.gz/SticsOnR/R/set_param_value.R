set_param_value <- function(xml_doc_object,param_name,param_value,
                            parent_name= NULL,
                            parent_sel_attr = NULL, ids=NULL){
  #' @title Setting parameter value for different kinds of parameters
  #'
  #' @description Setting parameter value in a xmlDocument object
  #'
  #' @param xml_doc_object an xmlDocument object
  #' @param param_name parameter name
  #' @param param_value parameter value
  #' @param parent_name parent node name or attribute name (optional)
  #' @param parent_sel_attr parent attribute value (optional)
  #' @param ids elements indices (optional)
  #'
  #' @examples
  #'
  #'
  #' @export
  #'
  # ----------------------------------------------------------------------
  #  MODIFICATIONS (last commit)
  #  $Date: 2019-06-19 10:32:46 +0200 (mer. 19 juin 2019) $
  #  $Author: plecharpent $
  #  $Revision: 1442 $
  # ----------------------------------------------------------------------

  param_types=get_param_type()

  # calling the function with an argument list
  if (length(param_name) > 1) {
    # if param_name is a vector or a list with input args !
    args <- c(list(xml_doc_object),as.list(param_name))
    return(do.call(set_param_value, args))
  }

  if ( is.numeric(parent_name) ) {
    ids = parent_name
    parent_name = NULL
  }

  if (is.numeric(parent_sel_attr)) {
    ids <- parent_sel_attr
    parent_sel_attr <- NULL
  }


  param_type <- get_param_type(xml_doc_object, param_name,
                               parent_name,parent_sel_attr, ids)
  type <- param_type$type
  xpath <- param_type$xpath

  if (! is.element(type,param_types) ) {
    stop("Type error !")
  }

  values_nb <- length(param_value)
  nodes_nb <- length(getNodeS(xml_doc_object,xpath))
  # checking dimensions between nodes ids and nodes number for xpath
  if ( is.null(ids) && values_nb > 1 && !values_nb == nodes_nb ) {
    stop("Replacement values are not consistent with parameters number !")
  }

  # TODO: see if could be simplified with a default case !
  switch(type,
         node= {
           setValues(xml_doc_object,xpath,param_value, ids)
         },
         attr= {
           #xpath=paste0('//option[@nomParam="',param_name,'"]')
           setAttrValues(xml_doc_object,xpath,"nom",param_value, ids)
         },
         param= {
           #xpath=paste0('//param[@nom="',param_name,'"]')

           setValues(xml_doc_object,xpath,param_value, ids)
         },
         option= {
           #xpath=paste0('//option[@nomParam="',param_name,'"]')
           setAttrValues(xml_doc_object,xpath,"choix",param_value, ids)
         },
         table= {
           #xpath=paste0('//param[@nom="',param_name,'"]')

           # check number if values
           if ( length(param_value) > param_type$length ) {
             stop("Too many values to set !")
           }
           setValues(xml_doc_object,xpath,param_value, ids)
         },
         table2= {

           if ( length(param_value) > param_type$length ) {
             stop("Too many values to set !")
           }
           setValues(xml_doc_object,xpath,param_value, ids)
         },
         choix_param= {
           setAttrValues(xml_doc_object,xpath,"choix",param_value,ids)
         },
         node_node= {
           setValues(xml_doc_object,xpath,param_value,ids)
         },
         node_table= {
           setValues(xml_doc_object,xpath,param_value,ids)
         },
         node_option= {
           setAttrValues(xml_doc_object,xpath,"choix",param_value,ids)
         },
         node_param= {
           setValues(xml_doc_object,xpath,param_value,ids)
         },
         form_option= {
           setAttrValues(xml_doc_object,xpath,"choix",param_value,ids)
         },
         node_attr= {
           setAttrValues(xml_doc_object,xpath,"nom",param_value,ids)
         },
         attr_attr= {
           setValues(xml_doc_object,xpath,param_value,ids)
         }


  )


  #return(xml_doc_object)
  return(invisible())
}
