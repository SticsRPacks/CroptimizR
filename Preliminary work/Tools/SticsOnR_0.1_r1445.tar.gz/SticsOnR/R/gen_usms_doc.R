gen_usms_doc <- function(xml_doc_object = NULL, usms_nb = NULL, usms_param = NULL) {

  #' @export
  #'

  out_doc_object <- gen_xml_doc(doc_type = "usms",
                                xml_doc_object,
                                nodes_nb = usms_nb,
                                nodes_param = usms_param)

  return(out_doc_object)

}
