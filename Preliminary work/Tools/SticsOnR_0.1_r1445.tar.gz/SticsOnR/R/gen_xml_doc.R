gen_xml_doc <- function(doc_type, xml_doc_object = NULL,
                        nodes_nb = NULL, nodes_param = NULL,
                        overwrite = T) {

  #' @export
  #'

  doc_types <- list()
  doc_types$usms <- list(root="usms",node="usm")
  doc_types$soils <- list(root="sols",node="sol")

  if ( ! nargs()) {
    return(names(doc_types))
  }

  if ( ! is.element(doc_type, names(doc_types)) ) {
    stop(paste0("The doc type is not an existing one: ",doc_type))
  }

  root <- doc_types[[doc_type]]$root
  node <- doc_types[[doc_type]]$node

  root_str <- paste0("/",root)
  node_str <- paste0("//",node)

  # getting a default xml template
  if ( is.null(xml_doc_object) ) {
    tmpl_file <- paste0("extdata/xml/templates/one_",root,".xml")
    xml_doc_object <- xmldocument(system.file(tmpl_file, package = "SticsOnR"))
  }

  elts_nb <- NULL

  # identity or single usms doc from the template file
  if ( all(is.null(c(nodes_nb, nodes_param))) ) {
    return(xml_doc_object)
  }

  # calculating nodes number
  if (! is.null(nodes_nb)) { elts_nb = nodes_nb }

  if ( "data.frame" %in% class(nodes_param) ) {
    elts_nb <- dim(nodes_param)[1]
  }

  # checking nodes number value
  if (is.null(elts_nb)) {
    stop("Error in usm number or in soils parameters table !")
  }

  # getting usm nodes
  xml_nodes <- getNodeS(xml_doc_object, node_str)

  # Nothing to do
  if ( length(xml_nodes) == elts_nb && is.null(nodes_param) ) {
    return(xml_doc_object)
  }

  # Keeping the usm node as model, deconnected from the xml document
  base_node_txt <- saveXML(xml_nodes[[1]])
  # Keeping only the usms parent node in the
  # xml document
  removeNodes(xml_nodes)

  # Adding usm nodes to usms node
  new_node <- getNodeSet(xmlParse(base_node_txt), node_str)[[1]]
  for ( u in 1:elts_nb ) {
    addNodes(xml_doc_object,new_node,root_str)
  }

  if ( is.null(nodes_param) ) {
    return(xml_doc_object)
  }

  # setting data according to doc_type
  switch( doc_type,
          usms = set_usms_param(xml_doc_object, nodes_param, overwrite = overwrite),
          soils = set_sols_param(xml_doc_object, nodes_param, overwrite = overwrite)
          )



  return(xml_doc_object)

}
