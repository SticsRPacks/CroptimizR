gen_sols_doc <- function(xml_doc_object = NULL, sols_nb = NULL, sols_param = NULL) {

  #' @export
  #'

  out_doc_object <- gen_xml_doc(doc_type = "soils",
                                xml_doc_object,
                                nodes_nb = sols_nb,
                                nodes_param = sols_param)

  return(out_doc_object)

}
