gen_sols_file <- function(sols_file_path, sols_nb = NULL, sols_param = NULL) {

  #' @export
  #'
  #'
  #'

  xml_doc_object <- gen_sols_doc(sols_nb = sols_nb, sols_param = sols_param)


  saveXmlDoc(xml_doc_object, sols_file_path)

  return(invisible(xml_doc_object))

}
