gen_usms_file <- function(usms_file_path, usms_nb = NULL, usms_param = NULL) {

  #' @export
  #'
  #'
  #'

  xml_doc_object <- gen_usms_doc(usms_nb = usms_nb, usms_param = usms_param)

  saveXmlDoc(xml_doc_object, usms_file_path)

  return(invisible(xml_doc_object))

}
