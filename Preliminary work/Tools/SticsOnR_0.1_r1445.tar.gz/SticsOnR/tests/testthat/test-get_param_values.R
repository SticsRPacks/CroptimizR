library(SticsOnR)
library(Classes)
xml_path="/home/plecharpent/Work/workspace/Example_Stics_Tests/R/SticsOnR/R/data/baresoil_plt.xml"
context("Getting param values")


test_that("single param option value", {
  expect_equal(get_param_values(xml_path,"codetemp"), "1")
  expect_equal(get_param_values(xml_path,"codegdh"), "1")
  expect_equal(get_param_values(xml_path,"codephot"), "2")
})

test_that("single param value", {
  expect_equal(get_param_values(xml_path,"jvcmini"),"7.00000")
  expect_equal(get_param_values(xml_path,"innsen"), "0.35000")
  expect_equal(get_param_values(xml_path,"efcroiveg"), "4.25000")
})

test_that("two param option values, and order", {
  expect_equal(get_param_values(xml_path,c("codetremp","codegdh")), c("2","1"))
  expect_equal(get_param_values(xml_path,c("codegdh","codetremp")), c("1","2"))
})

test_that("two param values, and order", {
  expect_equal(get_param_values(xml_path,c("jvcmini","innsen")),c("7.00000","0.35000"))
  expect_equal(get_param_values(xml_path,c("innsen","jvcmini")),c("0.35000","7.00000"))
})

test_that("a param option value and a param value, and order", {
  expect_equal(get_param_values(xml_path,c("codetemp","jvcmini")), c("1","7.00000"))
  expect_equal(get_param_values(xml_path,c("jvcmini","codetemp")), c("7.00000","1"))
})

