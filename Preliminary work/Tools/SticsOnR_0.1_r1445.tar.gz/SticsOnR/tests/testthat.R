library(testthat)
library(SticsOnR)

test_check("SticsOnR")
