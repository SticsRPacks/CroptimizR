xpath<- "//ta_entete"
> getNodeS(xdoc,xpath)
[[1]]
<ta_entete nb_colonnes="7">
  <colonne nom="julres"/>
    <colonne nom="coderes"/>
      <colonne nom="qres"/>
        <colonne nom="Crespc"/>
          <colonne nom="CsurNres"/>
            <colonne nom="Nminres"/>
              <colonne nom="eaures"/>
                </ta_entete>

                [[2]]
              <ta_entete nb_colonnes="3">
                <colonne nom="jultrav"/>
                  <colonne nom="profres"/>
                    <colonne nom="proftrav"/>
                      </ta_entete>

                      [[3]]
                    <ta_entete nb_colonnes="2">
                      <colonne nom="julapI_or_sum_upvt"/>
                        <colonne nom="amount"/>
                          </ta_entete>

                          [[4]]
                        <ta_entete nb_colonnes="2">
                          <colonne nom="julapN_or_sum_upvt"/>
                            <colonne nom="absolute_value/%"/>
                              </ta_entete>

                              [[5]]
                            <ta_entete nb_colonnes="5">
                              <colonne nom="julfauche"/>
                                <colonne nom="hautcoupe"/>
                                  <colonne nom="lairesiduel"/>
                                    <colonne nom="msresiduel"/>
                                      <colonne nom="anitcoupe"/>
                                        </ta_entete>

                                        [[6]]
                                      <ta_entete nb_colonnes="5">
                                        <colonne nom="tempfauche"/>
                                          <colonne nom="hautcoupe"/>
                                            <colonne nom="lairesiduel"/>
                                              <colonne nom="msresiduel"/>
                                                <colonne nom="anitcoupe"/>
                                                  </ta_entete>

                                                  attr(,"class")
                                                [1] "XMLNodeSet"
                                                > getNodeLocation(xdoc,xpath)
                                                Error in UseMethod("getSibling") :
                                                  pas de méthode pour 'getSibling' applicable pour un objet de classe "c('xmlDocument', 'fileDocument')"
                                          xpath<- "//ta_entete"
                                                > getAttrsValues(xdoc, xpath, "nb_colonnes")
                                                nb_colonnes
                                                [1,] "7"
                                                [2,] "3"
                                                [3,] "2"
                                                [4,] "2"
                                                [5,] "5"
                                                [6,] "5"
                                                > xpath<- "//ta_entete/.."
                                                > getAttrsValues(xdoc, xpath, "nb_interventions")
                                                nb_interventions
                                                [1,] "1"
                                                [2,] "1"
                                                [3,] "0"
                                                [4,] "2"
                                                [5,] "0"
                                                [6,] "0"
                                                > xpath<- "//ta_entete/../.."
                                                > getAttrsValues(xdoc, xpath, "nom")
                                                nom
                                                [1,] "supply of organic residus"
                                                [2,] "soil tillage"
                                                [3,] "no"
                                                [4,] "fertilisation"
                                                [5,] "calendar in days"
                                                [6,] "calendar in degree days"
                                                >
